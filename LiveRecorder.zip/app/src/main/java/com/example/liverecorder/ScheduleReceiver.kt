package com.example.liverecorder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** AlarmManager tetiklenince kaydı başlatır (tam zamanlı alarm, ön plan servisi başlatma izni verir). */
class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.remove(ctx, intent.getIntExtra("sched_id", -1))
        ctx.startForegroundService(Intent(ctx, RecorderService::class.java).putExtras(intent))
    }
}
