package com.example.liverecorder

import android.app.Application

class LiveApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        AppLog.init(this)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            AppLog.e("ÇÖKME (${t.name})", e)
            old?.uncaughtException(t, e)
        }
    }
}
