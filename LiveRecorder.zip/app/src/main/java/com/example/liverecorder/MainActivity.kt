package com.example.liverecorder

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class Entry(
    val key: String,
    var url: String,
    var headers: HashMap<String, String>,
    var info: StreamInfo? = null,
    val manual: Boolean = false,
    val title: String = ""
)

class MainActivity : LockedActivity() {

    private class Plan(
        val url: String,
        val h: HashMap<String, String>,
        val type: String,
        var bw: Long = 0L,
        var audioOnly: Boolean = false,
        val title: String = ""
    )

    private lateinit var web: WebView
    private lateinit var urlBar: EditText
    private lateinit var adapter: ArrayAdapter<String>
    private val entries = LinkedHashMap<String, Entry>()
    private var shown: List<Entry> = emptyList()
    private val labels = ArrayList<String>()
    private val pool = Executors.newFixedThreadPool(2)
    private val verified = HashSet<String>()
    private var verifyCount = 0
    @Volatile private var pageUrl: String? = null
    @Volatile private var ua: String = ""
    private var darkAtCreate = false

    // Reklam / izleme isteklerini listeye alma
    private val bad = listOf(
        "doubleclick", "googlesyndication", "imasdk", "/ads/", "/ad/", "adserver",
        "adsystem", "preroll", "advert", "/beacon", "analytics"
    )
    private val skipExt = setOf(
        "js", "css", "png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "woff", "woff2",
        "ttf", "json", "html", "htm", "ts", "m4s", "map", "txt"
    )
    private val directExt = setOf("mp3", "aac", "ogg", "opus", "m4a", "mp4", "flv", "webm")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeUtil.apply(this)
        super.onCreate(savedInstanceState)
        darkAtCreate = Prefs.dark
        Thread { Cleanup.run(applicationContext) }.start()
        setContentView(R.layout.activity_main)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        web = findViewById(R.id.web)
        urlBar = findViewById(R.id.urlBar)
        val list = findViewById<ListView>(R.id.list)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        list.adapter = adapter

        ua = web.settings.userAgentString
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                pageUrl = url
                urlBar.setText(url)
                entries.values.removeIf { !it.manual } // yeni sayfa = yeni yayın listesi
                verified.clear()
                verifyCount = 0
                refresh()
            }

            override fun onPageFinished(view: WebView, url: String) {
                Library.addHistory(view.title ?: url, url)
            }

            // Arka plan thread'inde çağrılır: yayın isteklerini ve başlıklarını yakalar.
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val u = request.url.toString()
                val low = u.lowercase()
                if (Prefs.adBlock && AdBlock.isAd(request.url.host)) {
                    return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                }
                val path = low.substringBefore('?')
                val last = path.substringAfterLast('/')
                val ext = if (last.contains('.')) last.substringAfterLast('.') else ""

                val definite = path.endsWith(".m3u8") || path.endsWith(".mpd") || path.contains(".m3u8/")
                val hint = low.contains("m3u8") || low.contains("manifest") || low.contains("playlist") ||
                    low.contains("format=hls") || low.contains("/hls/")
                val range = request.requestHeaders["Range"] != null
                val candidate = !definite && ext !in skipExt && (ext in directExt || hint || range)
                if (!definite && !candidate) return null
                if (bad.any { low.contains(it) }) return null

                val h = HashMap<String, String>()
                h["User-Agent"] = ua
                (request.requestHeaders["Referer"] ?: pageUrl)?.let { h["Referer"] = it }
                request.requestHeaders["Origin"]?.let { h["Origin"] = it }
                CookieManager.getInstance().getCookie(u)?.let { h["Cookie"] = it }
                runOnUiThread { if (definite) onFound(u, h) else onCandidate(u, h) }
                return null
            }
        }

        findViewById<Button>(R.id.goBtn).apply {
            setOnClickListener { go() }
            // Uzun bas: adres çubuğundaki linki (uzantısız olsa da) yayın olarak ekle (ör. radyo linki)
            setOnLongClickListener {
                val t = urlBar.text.toString().trim()
                if (t.startsWith("http://") || t.startsWith("https://")) askManual(t)
                else Toast.makeText(context, "Önce bir http(s) linki yapıştır", Toast.LENGTH_SHORT).show()
                true
            }
        }
        urlBar.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) { go(); true } else false
        }

        list.setOnItemClickListener { _, _, pos, _ ->
            if (pos < shown.size) probeAndAsk(shown[pos])
        }

        findViewById<Button>(R.id.menuBtn).setOnClickListener { showMenu() }
        findViewById<Button>(R.id.recordsBtn).setOnClickListener {
            startActivity(Intent(this, RecordingsActivity::class.java))
        }
        findViewById<Button>(R.id.scheduleBtn).setOnClickListener {
            startActivity(Intent(this, SchedulesActivity::class.java))
        }
        findViewById<Button>(R.id.stopBtn).setOnClickListener {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
        }

        if (!handleIntent(intent)) web.loadUrl("https://www.google.com")
    }

    // ---- Tür tahmini / link denetimi ----
    private fun extOf(u: String): String {
        val last = u.substringBefore('?').lowercase().substringAfterLast('/')
        return if (last.contains('.')) last.substringAfterLast('.') else ""
    }

    private fun guessType(u: String): String = when {
        u.substringBefore('?').lowercase().endsWith(".mpd") -> "dash"
        extOf(u) in directExt -> "direct"
        else -> "hls"
    }

    private fun isStreamUrl(u: String): Boolean {
        val p = u.substringBefore('?').lowercase()
        return (p.startsWith("http://") || p.startsWith("https://")) &&
            (p.endsWith(".m3u8") || p.endsWith(".mpd") || extOf(u) in directExt)
    }

    // ---- Elle girilen / paylaşılan linkler ----
    /** Başka uygulamadan paylaşılan/açılan linki işler. İşlediyse true döner. */
    private fun handleIntent(i: Intent?): Boolean {
        if (i == null) return false
        val d = i.data
        if (i.action == Intent.ACTION_VIEW && d != null && (d.scheme == "content" || d.scheme == "file")) {
            startIptv(null, d) // dosya yöneticisinden açılan .m3u listesi
            return true
        }
        val text = when (i.action) {
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> i.dataString
            else -> null
        } ?: return false
        val link = Regex("https?://\\S+").find(text)?.value ?: return false
        if (link.substringBefore('?').lowercase().endsWith(".m3u")) {
            startIptv(link, null) // M3U (IPTV) listesi linki
            return true
        }
        val streamish = i.type?.lowercase()?.let { it.contains("mpegurl") || it.contains("dash") } == true
        if (streamish || isStreamUrl(link)) askManual(link)
        else if (Social.isSocial(link)) {
            if (i.action == Intent.ACTION_SEND && Prefs.quickShare) {
                // Hızlı paylaş: soru sormadan varsayılan kaliteyle indir, önceki uygulamaya dön
                startSocial(link, "", false, Prefs.socialHeight)
                if (web.url == null) web.loadUrl("https://www.google.com")
                moveTaskToBack(true)
            } else {
                askSocial(link, "", true)
            }
        }
        else web.loadUrl(link)
        return true
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun askManual(u: String) {
        val et = EditText(this)
        et.hint = "Referer (gerekmiyorsa boş bırak)"
        AlertDialog.Builder(this)
            .setTitle("Yayın linki")
            .setMessage(u)
            .setView(et)
            .setPositiveButton("Devam") { _, _ -> addManual(u, et.text.toString().trim()) }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun addManual(u: String, referer: String) {
        val h = HashMap<String, String>()
        h["User-Agent"] = ua
        if (referer.isNotEmpty()) {
            h["Referer"] = referer
            val p = Uri.parse(referer)
            if (p.scheme != null && p.host != null) h["Origin"] = "${p.scheme}://${p.host}"
        }
        CookieManager.getInstance().getCookie(u)?.let { h["Cookie"] = it }
        val e = Entry(u.substringBefore('?'), u, h, manual = true)
        entries[e.key] = e
        refresh()
        Toast.makeText(this, "Yayın kontrol ediliyor…", Toast.LENGTH_SHORT).show()
        pool.execute {
            val info = try { StreamProbe.analyze(u, h) } catch (ex: Exception) { AppLog.add("W", "Analiz başarısız (${ex.message}): $u"); null }
            runOnUiThread {
                e.info = info ?: StreamInfo("analiz edilemedi", -50, guessType(u))
                refresh()
                probeAndAsk(e)
            }
        }
    }

    // ---- Bulunan yayınlar: tekilleştir, analiz et, sırala ----
    private fun onFound(u: String, h: HashMap<String, String>) {
        val key = u.substringBefore('?')
        val old = entries[key]
        if (old != null) { // aynı yayın: taze token/başlıkları sakla
            old.url = u
            old.headers = h
            return
        }
        val e = Entry(key, u, h, title = web.title ?: "")
        entries[key] = e
        refresh()
        pool.execute {
            val info = try { StreamProbe.analyze(u, h) } catch (ex: Exception) { AppLog.add("W", "Analiz başarısız (${ex.message}): $u"); null }
            runOnUiThread {
                e.info = info ?: StreamInfo("analiz edilemedi", -50, guessType(u))
                refresh()
            }
        }
    }

    /** Uzantısız/belirsiz istekler: önce içerik türüne bakıp gerçekten yayın mı doğrula. */
    private fun onCandidate(u: String, h: HashMap<String, String>) {
        val key = u.substringBefore('?')
        if (entries.containsKey(key) || !verified.add(key) || verifyCount >= 25) return
        val dir = key.substringBeforeLast('/')
        if (entries.keys.any { it.substringBeforeLast('/') == dir }) return // yayının parçaları
        verifyCount++
        pool.execute {
            val info = try { StreamProbe.analyze(u, h) } catch (ex: Exception) { AppLog.add("W", "Analiz başarısız (${ex.message}): $u"); null }
            if (info != null) runOnUiThread {
                if (!entries.containsKey(key)) {
                    entries[key] = Entry(key, u, h, info, title = web.title ?: "")
                    refresh()
                }
            }
        }
    }

    private fun shortUrl(u: String): String {
        val p = Uri.parse(u)
        return "${p.host}/…/${p.lastPathSegment}"
    }

    private fun refresh() {
        shown = entries.values.reversed().sortedByDescending { it.info?.score ?: 0 }
        labels.clear()
        shown.forEachIndexed { i, e ->
            val star = if (i == 0 && (e.info?.score ?: 0) > 0) "★ " else ""
            labels.add(star + (e.info?.label ?: "Analiz ediliyor…") + "\n" + shortUrl(e.url))
        }
        adapter.notifyDataSetChanged()
    }

    private fun go() {
        val t = urlBar.text.toString().trim()
        if (t.isEmpty()) return
        if (isStreamUrl(t)) { askManual(t); return }
        val target = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(t, "UTF-8")
        }
        web.loadUrl(target)
    }

    // ---- Akış: kalite -> (şimdi | sadece ses | zamanla) ----
    private fun probeAndAsk(e: Entry) {
        val plan = Plan(e.url, e.headers, e.info?.type ?: guessType(e.url), title = e.title)
        if (plan.type == "direct") { askMode(plan); return }
        Toast.makeText(this, "Kaliteler aranıyor…", Toast.LENGTH_SHORT).show()
        Thread {
            val q = try { QualityProbe.probe(plan.url, plan.h) } catch (ex: Exception) { emptyList() }
            runOnUiThread { if (q.isEmpty()) askMode(plan) else askQuality(plan, q) }
        }.start()
    }

    private fun askQuality(plan: Plan, q: List<Quality>) {
        val opts = (listOf("En iyi kalite") + q.map { it.label }).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Kalite")
            .setItems(opts) { _, i ->
                plan.bw = if (i == 0) 0L else q[i - 1].bandwidth
                askMode(plan)
            }
            .show()
    }

    private fun askMode(plan: Plan) {
        val opts = ArrayList<String>()
        opts.add("Şimdi kaydet")
        opts.add("Önizle (izle)")
        if (plan.type != "direct") opts.add("Sadece ses kaydet")
        opts.add("Zamanla…")
        opts.add("Yayın başlayınca kaydet")
        AlertDialog.Builder(this)
            .setTitle("Kayıt")
            .setItems(opts.toTypedArray()) { _, i ->
                val c = opts[i]
                when {
                    c.startsWith("Şimdi") -> startNow(plan)
                    c.startsWith("Önizle") -> preview(plan)
                    c.startsWith("Sadece") -> { plan.audioOnly = true; startNow(plan) }
                    c.startsWith("Zamanla") -> pickTime(plan)
                    else -> pickWatch(plan)
                }
            }
            .show()
    }

    private fun ensureExact(): Boolean {
        val am = getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            Toast.makeText(this, "Bunun için 'Alarmlar ve hatırlatıcılar' iznini aç", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return false
        }
        return true
    }

    /** Yayın açılınca otomatik kayıt: linki düzenli aralıkla kontrol eder. */
    private fun pickWatch(plan: Plan) {
        if (!ensureExact()) return
        val mins = intArrayOf(2, 5, 15)
        val def = mins.indexOf(Prefs.watchMin).coerceAtLeast(0)
        val opts = arrayOf("2 dk", "5 dk", "15 dk").mapIndexed { i, t -> if (i == def) "$t (varsayılan)" else t }
        AlertDialog.Builder(this)
            .setTitle("Kaç dakikada bir kontrol edilsin?")
            .setItems(opts.toTypedArray()) { _, i ->
                val id = 1_000_000_000 + (System.currentTimeMillis() % 900_000_000L).toInt()
                Watcher.add(this, Watch(id, plan.url, plan.h, plan.bw, plan.type, plan.audioOnly, mins[i], plan.title))
                Toast.makeText(this, "Yayın izleniyor; açılınca kayıt başlayacak (Zamanlı düğmesinden iptal)",
                    Toast.LENGTH_LONG).show()
            }
            .show()
    }

    private fun showMenu() {
        val opts = arrayOf(
            "IPTV (M3U listeleri, kategoriler, VOD, kayıt)",
            "Bu sayfadaki videoyu indir (Instagram, Facebook, TikTok…)",
            "Bu sayfayı yer imi yap", "Yer imleri", "Geçmiş", "Ayarlar", "Günlük (hata kayıtları)"
        )
        AlertDialog.Builder(this).setItems(opts) { _, i ->
            when (i) {
                0 -> startIptv(null, null)
                1 -> {
                    val u = web.url
                    if (u != null && u.startsWith("http")) askSocial(u, web.title ?: "", false)
                    else Toast.makeText(this, "Önce bir sayfa aç", Toast.LENGTH_SHORT).show()
                }
                2 -> {
                    val u = web.url
                    if (u != null) {
                        Library.addBookmark(web.title ?: u, u)
                        Toast.makeText(this, "Yer imi eklendi", Toast.LENGTH_SHORT).show()
                    }
                }
                3 -> startActivity(Intent(this, BookmarksActivity::class.java).putExtra("kind", "bookmarks"))
                4 -> startActivity(Intent(this, BookmarksActivity::class.java).putExtra("kind", "history"))
                5 -> startActivity(Intent(this, SettingsActivity::class.java))
                else -> startActivity(Intent(this, LogActivity::class.java))
            }
        }.show()
    }

    private fun startIptv(addUrl: String?, data: Uri?) {
        val i = Intent(this, IptvActivity::class.java)
        if (addUrl != null) i.putExtra("addUrl", addUrl)
        if (data != null) {
            i.data = data
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(i)
    }

    // ---- Sosyal medya video indirme (yt-dlp) ----
    private fun askSocial(url: String, title: String, canOpen: Boolean) {
        val labels = arrayListOf(
            "Video • en iyi kalite", "Video • 1080p'ye kadar", "Video • 720p'ye kadar",
            "Video • 480p'ye kadar", "Sadece ses"
        )
        val heights = intArrayOf(0, 1080, 720, 480, -1) // -1 = yalnızca ses
        if (canOpen) labels.add("Sayfada aç (giriş yapmak için)")
        AlertDialog.Builder(this)
            .setTitle("Video indir")
            .setMessage(url)
            .setItems(labels.toTypedArray()) { _, i ->
                when {
                    i >= heights.size -> web.loadUrl(url)
                    heights[i] < 0 -> startSocial(url, title, true, 0)
                    else -> startSocial(url, title, false, heights[i])
                }
            }
            .show()
    }

    private fun startSocial(url: String, title: String, audioOnly: Boolean, height: Int) {
        val cookies = CookieFile.write(this, url)
        startForegroundService(
            Intent(this, RecorderService::class.java)
                .putExtra("url", url).putExtra("type", "social").putExtra("audioOnly", audioOnly)
                .putExtra("height", height).putExtra("title", title).putExtra("cookies", cookies)
        )
        Toast.makeText(this, "İndirme başladı (bildirimden izleyebilirsin)", Toast.LENGTH_LONG).show()
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.dark != darkAtCreate) recreate()
    }

    private fun preview(plan: Plan) {
        if (plan.type == "dash") {
            Toast.makeText(this, "Önizleme DASH (mpd) için desteklenmiyor", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(
            Intent(this, PlayerActivity::class.java).setData(Uri.parse(plan.url)).putExtra("headers", plan.h)
        )
    }

    // ---- Panodaki yayın linki ----
    private var lastClip = ""
    private var lastClipCheck = 0L

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || !Prefs.clipWatch) return
        val now = System.currentTimeMillis()
        if (now - lastClipCheck < 3000) return
        lastClipCheck = now
        val cm = getSystemService(ClipboardManager::class.java)
        if (!cm.hasPrimaryClip()) return
        val clip = cm.primaryClip ?: return
        if (clip.itemCount == 0) return
        val t = clip.getItemAt(0).text?.toString() ?: return
        val link = Regex("https?://\\S+").find(t)?.value ?: return
        val low = link.lowercase()
        if (link == lastClip) return
        val stream = isStreamUrl(link) || low.contains(".m3u8") || low.contains(".mpd")
        val social = Social.isSocial(link)
        if (!stream && !social) return
        lastClip = link
        AlertDialog.Builder(this)
            .setTitle(if (stream) "Panoda yayın linki var" else "Panoda sosyal medya linki var")
            .setMessage(link)
            .setPositiveButton(if (stream) "Kaydet" else "İndir") { _, _ ->
                if (stream) askManual(link) else askSocial(link, "", true)
            }
            .setNegativeButton("Hayır", null)
            .show()
    }

    private fun startNow(plan: Plan) {
        startForegroundService(
            Intent(this, RecorderService::class.java)
                .putExtra("url", plan.url).putExtra("headers", plan.h)
                .putExtra("bandwidth", plan.bw).putExtra("type", plan.type)
                .putExtra("audioOnly", plan.audioOnly).putExtra("title", plan.title)
        )
        Toast.makeText(this, "Kayıt başladı", Toast.LENGTH_SHORT).show()
    }

    // ---- Zamanlayıcı ----
    private fun pickTime(plan: Plan) {
        val am = getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            Toast.makeText(this, "Zamanlama için 'Alarmlar ve hatırlatıcılar' iznini aç", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return
        }
        val now = Calendar.getInstance()
        TimePickerDialog(this, { _, hh, mm ->
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hh); set(Calendar.MINUTE, mm)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val opts = arrayOf("15 dk", "30 dk", "1 saat", "2 saat", "Sınırsız")
            val mins = intArrayOf(15, 30, 60, 120, 0)
            AlertDialog.Builder(this)
                .setTitle("Kayıt süresi")
                .setItems(opts) { _, i -> setAlarm(plan, cal.timeInMillis, mins[i]) }
                .show()
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
    }

    private fun setAlarm(plan: Plan, whenMs: Long, durMin: Int) {
        val id = (System.currentTimeMillis() % 1_000_000_000L).toInt()
        Scheduler.add(this, Sched(id, whenMs, plan.url, plan.h, plan.bw, durMin, plan.type, plan.audioOnly, plan.title))
        val t = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(whenMs))
        Toast.makeText(this, "Kayıt $t'de başlayacak (Zamanlı düğmesinden iptal edebilirsin)", Toast.LENGTH_LONG).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
