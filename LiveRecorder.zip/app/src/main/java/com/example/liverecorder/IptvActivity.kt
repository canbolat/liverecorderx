package com.example.liverecorder

import android.app.AlarmManager
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** IPTV: M3U playlist yönetimi, kategoriler, arama, favoriler, EPG, canlı kayıt ve VOD indirme. */
class IptvActivity : LockedActivity() {

    private var metas: List<PlaylistMeta> = emptyList()
    private var cur: PlaylistMeta? = null
    private var parsed: Parsed? = null
    private var epg: Map<String, List<Prog>> = emptyMap()
    private var favSet: Set<String> = emptySet()
    private var tab = 0 // 0 canlı, 1 VOD, 2 favoriler
    private var group: String? = null
    private var query = ""
    private var shown: List<Channel> = emptyList()
    private val groupCounts = LinkedHashMap<String, Int>()

    private lateinit var listBtn: Button
    private lateinit var tabBtns: List<Button>
    private lateinit var catBtn: Button
    private lateinit var search: EditText
    private lateinit var info: TextView
    private lateinit var lv: ListView
    private val adapter = ChannelAdapter()

    private class Holder(val logo: ImageView, val t1: TextView, val t2: TextView)

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun hm(t: Long) = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))
    private fun looksM3u(s: String) = s.contains("#EXTM3U") || s.contains("#EXTINF")

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeUtil.apply(this)
        super.onCreate(savedInstanceState)
        buildUi()
        metas = IptvStore.playlists(this)
        val saved = IptvStore.currentId(this)
        cur = metas.firstOrNull { it.id == saved } ?: metas.firstOrNull()
        loadCurrent()

        val data = intent.data
        val addUrl = intent.getStringExtra("addUrl")
        if (data != null) importFromUri(data)
        else if (addUrl != null) showLinkDialog(addUrl)
        else if (metas.isEmpty()) showAdd()
    }

    // ---------------- Arayüz ----------------
    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.fitsSystemWindows = true

        val r1 = LinearLayout(this)
        listBtn = Button(this)
        listBtn.text = "Playlist seç"
        listBtn.setOnClickListener { showPlaylists() }
        r1.addView(listBtn, LinearLayout.LayoutParams(0, -2, 1f))
        val addBtn = Button(this)
        addBtn.text = "＋"
        addBtn.setOnClickListener { showAdd() }
        r1.addView(addBtn, LinearLayout.LayoutParams(-2, -2))
        val moreBtn = Button(this)
        moreBtn.text = "⋮"
        moreBtn.setOnClickListener { showMore() }
        r1.addView(moreBtn, LinearLayout.LayoutParams(-2, -2))
        root.addView(r1, LinearLayout.LayoutParams(-1, -2))

        val r2 = LinearLayout(this)
        tabBtns = listOf("Canlı TV", "VOD", "★ Favoriler").mapIndexed { i, t ->
            val b = Button(this)
            b.text = t
            b.setOnClickListener { tab = i; group = null; refreshList() }
            r2.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
            b
        }
        root.addView(r2, LinearLayout.LayoutParams(-1, -2))

        val r3 = LinearLayout(this)
        catBtn = Button(this)
        catBtn.text = "Kategori: Tümü ▾"
        catBtn.setOnClickListener { showCategories() }
        r3.addView(catBtn, LinearLayout.LayoutParams(0, -2, 1f))
        search = EditText(this)
        search.hint = "Ara…"
        search.maxLines = 1
        search.inputType = android.text.InputType.TYPE_CLASS_TEXT
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                query = s?.toString() ?: ""
                refreshList()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        r3.addView(search, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(r3, LinearLayout.LayoutParams(-1, -2))

        info = TextView(this)
        info.textSize = 12f
        info.setPadding(16, 4, 16, 4)
        root.addView(info, LinearLayout.LayoutParams(-1, -2))

        lv = ListView(this)
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, pos, _ -> if (pos < shown.size) play(pos) }
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos < shown.size) actions(shown[pos], pos)
            true
        }
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private inner class ChannelAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val h: Holder
            val row: View
            if (convertView == null) {
                val dp = resources.displayMetrics.density
                val r = LinearLayout(this@IptvActivity)
                r.orientation = LinearLayout.HORIZONTAL
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding((10 * dp).toInt(), (8 * dp).toInt(), (10 * dp).toInt(), (8 * dp).toInt())
                val logo = ImageView(this@IptvActivity)
                logo.scaleType = ImageView.ScaleType.FIT_CENTER
                r.addView(logo, LinearLayout.LayoutParams((48 * dp).toInt(), (48 * dp).toInt()))
                val col = LinearLayout(this@IptvActivity)
                col.orientation = LinearLayout.VERTICAL
                val t1 = TextView(this@IptvActivity)
                t1.textSize = 16f
                t1.maxLines = 1
                t1.ellipsize = TextUtils.TruncateAt.END
                val t2 = TextView(this@IptvActivity)
                t2.textSize = 12f
                t2.maxLines = 1
                t2.ellipsize = TextUtils.TruncateAt.END
                t2.alpha = 0.7f
                col.addView(t1)
                col.addView(t2)
                val lp = LinearLayout.LayoutParams(0, -2, 1f)
                lp.leftMargin = (10 * dp).toInt()
                r.addView(col, lp)
                h = Holder(logo, t1, t2)
                r.tag = h
                row = r
            } else {
                row = convertView
                h = convertView.tag as Holder
            }
            val ch = shown[position]
            h.t1.text = (if (ch.url in favSet) "★ " else "") + ch.name
            val now = if (ch.vod) null else Epg.now(epg, ch.tvgId, System.currentTimeMillis())
            h.t2.text = ch.group + (if (now != null) " • ▶ ${now.title}" else "")
            LogoLoader.load(ch.logo, h.logo)
            return row
        }
    }

    // ---------------- Liste ----------------
    private fun loadCurrent() {
        val m = cur
        if (m == null) {
            listBtn.text = "Playlist yok — ＋ ile ekle"
            parsed = null
            shown = emptyList()
            adapter.notifyDataSetChanged()
            info.text = "M3U linki veya dosyası ekleyerek başla."
            updateTabs()
            return
        }
        listBtn.text = "${m.name} ▾"
        info.text = "Yükleniyor…"
        val id = m.id
        Thread {
            try {
                val p = IptvStore.load(this, id)
                val e = Epg.load(this, id)
                runOnUiThread {
                    if (cur?.id == id) {
                        parsed = p
                        epg = e
                        refreshList()
                        if (p.skipped > 0) toast("${p.skipped} kanal desteklenmeyen protokol (rtmp/udp) nedeniyle atlandı")
                        if (m.epgUrl.isNotEmpty() && Epg.isStale(this, id)) updateEpg(m, true)
                    }
                }
            } catch (ex: Exception) {
                AppLog.e("IPTV yükleme", ex)
                runOnUiThread { info.text = "Liste okunamadı: ${ex.message}" }
            }
        }.start()
    }

    private fun updateTabs() {
        tabBtns.forEachIndexed { i, b -> b.alpha = if (i == tab) 1f else 0.5f }
    }

    private fun refreshList() {
        updateTabs()
        val p = parsed ?: return
        favSet = IptvStore.favs(this)
        var list: List<Channel> = p.channels
        list = when (tab) {
            0 -> list.filter { !it.vod }
            1 -> list.filter { it.vod }
            else -> list.filter { it.url in favSet }
        }
        groupCounts.clear()
        list.forEach { groupCounts[it.group] = (groupCounts[it.group] ?: 0) + 1 }
        val g = group
        if (g != null && !groupCounts.containsKey(g)) group = null
        val g2 = group
        if (g2 != null) list = list.filter { it.group == g2 }
        if (query.isNotBlank()) list = list.filter { it.name.contains(query, true) }
        shown = list
        catBtn.text = "Kategori: ${group ?: "Tümü"} ▾"
        info.text = "${shown.size} öğe • dokun: izle • uzun bas: kaydet / indir / favori"
        adapter.notifyDataSetChanged()
    }

    private fun showCategories() {
        val keys = groupCounts.keys.toList()
        val names = ArrayList<String>()
        names.add("Tümü (${groupCounts.values.sum()})")
        keys.forEach { names.add("$it (${groupCounts[it]})") }
        AlertDialog.Builder(this)
            .setTitle("Kategori")
            .setItems(names.toTypedArray()) { _, i ->
                group = if (i == 0) null else keys[i - 1]
                refreshList()
            }
            .show()
    }

    private fun play(pos: Int) {
        IptvStore.queue = shown
        IptvStore.queueIndex = pos
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("iptv", true))
    }

    // ---------------- Kanal eylemleri ----------------
    private fun actions(ch: Channel, pos: Int) {
        val fav = ch.url in favSet
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        labels.add("İzle"); acts.add { play(pos) }
        if (ch.vod) {
            labels.add("İndir"); acts.add { record(ch, 0) }
        } else {
            labels.add("Şimdi kaydet"); acts.add { record(ch, 0) }
            labels.add("Zamanla…"); acts.add { scheduleDialog(ch) }
            labels.add("Yayın başlayınca kaydet"); acts.add { watch(ch) }
            labels.add("Program rehberi (EPG)"); acts.add { epgDialog(ch) }
        }
        labels.add(if (fav) "Favorilerden çıkar" else "Favoriye ekle")
        acts.add { IptvStore.toggleFav(this, ch.url); refreshList() }
        AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }

    private fun record(ch: Channel, durationMin: Int) {
        toast("Yayın kontrol ediliyor…")
        Thread {
            val t = Iptv.detectType(ch.url, ch.headers)
            runOnUiThread {
                startForegroundService(Iptv.recordIntent(this, ch, t, durationMin))
                toast((if (ch.vod) "İndirme başladı: " else "Kayıt başladı: ") + ch.name)
            }
        }.start()
    }

    private fun ensureExact(): Boolean {
        val am = getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            toast("Bunun için 'Alarmlar ve hatırlatıcılar' iznini aç")
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return false
        }
        return true
    }

    private fun scheduleDialog(ch: Channel) {
        if (!ensureExact()) return
        val now = Calendar.getInstance()
        TimePickerDialog(this, { _, hh, mm ->
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hh); set(Calendar.MINUTE, mm)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val opts = arrayOf("15 dk", "30 dk", "1 saat", "2 saat", "3 saat", "Sınırsız")
            val mins = intArrayOf(15, 30, 60, 120, 180, 0)
            AlertDialog.Builder(this)
                .setTitle("Kayıt süresi")
                .setItems(opts) { _, i -> schedule(ch, cal.timeInMillis, mins[i]) }
                .show()
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
    }

    private fun schedule(ch: Channel, whenMs: Long, durMin: Int) {
        Thread {
            val type = Iptv.detectType(ch.url, ch.headers)
            val id = (System.currentTimeMillis() % 1_000_000_000L).toInt()
            Scheduler.add(this, Sched(id, whenMs, ch.url, ch.headers, 0L, durMin, type, false, ch.name))
            runOnUiThread { toast("${ch.name} kaydı ${hm(whenMs)}'de başlayacak (Zamanlı ekranından iptal edilir)") }
        }.start()
    }

    private fun watch(ch: Channel) {
        if (!ensureExact()) return
        val mins = intArrayOf(2, 5, 15)
        AlertDialog.Builder(this)
            .setTitle("Kaç dakikada bir kontrol edilsin?")
            .setItems(arrayOf("2 dk", "5 dk", "15 dk")) { _, i ->
                Thread {
                    val type = Iptv.detectType(ch.url, ch.headers)
                    val id = 1_000_000_000 + (System.currentTimeMillis() % 900_000_000L).toInt()
                    Watcher.add(this, Watch(id, ch.url, ch.headers, 0L, type, false, mins[i], ch.name))
                    runOnUiThread { toast("İzleniyor: ${ch.name}. Yayın açılınca kayıt başlar.") }
                }.start()
            }
            .show()
    }

    // ---------------- EPG ----------------
    private fun epgDialog(ch: Channel) {
        val now = System.currentTimeMillis()
        val list = Epg.upcoming(epg, ch.tvgId, now, 12)
        if (list.isEmpty()) {
            toast("Bu kanal için program bilgisi yok. ⋮ menüsünden EPG'yi güncelle (kanalda tvg-id gerekir).")
            return
        }
        AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setItems(list.map { "${hm(it.start)}–${hm(it.stop)}  ${it.title}" }.toTypedArray()) { _, i ->
                progDialog(ch, list[i])
            }
            .show()
    }

    private fun progDialog(ch: Channel, p: Prog) {
        AlertDialog.Builder(this)
            .setTitle(p.title)
            .setMessage("${hm(p.start)}–${hm(p.stop)}\n\n${p.desc.ifEmpty { "(açıklama yok)" }}")
            .setPositiveButton("Bu programı kaydet") { _, _ -> recordProg(ch, p) }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun recordProg(ch: Channel, p: Prog) {
        val now = System.currentTimeMillis()
        if (p.start <= now + 60_000L) {
            record(ch, ((p.stop - now) / 60_000L + 2).toInt().coerceAtLeast(1))
        } else {
            if (!ensureExact()) return
            schedule(ch, p.start - 60_000L, ((p.stop - p.start) / 60_000L + 3).toInt())
        }
    }

    private fun updateEpg(m: PlaylistMeta, quiet: Boolean) {
        if (m.epgUrl.isEmpty()) { epgUrlDialog(m); return }
        if (!quiet) toast("EPG indiriliyor, büyük dosyalarda bir dakika sürebilir…")
        Thread {
            try {
                Epg.refresh(this, m.id, m.epgUrl)
                val e = Epg.load(this, m.id, true)
                runOnUiThread {
                    if (cur?.id == m.id) { epg = e; adapter.notifyDataSetChanged() }
                    if (!quiet) toast("EPG hazır (${e.size} kanal)")
                }
            } catch (ex: Exception) {
                AppLog.e("EPG", ex)
                if (!quiet) runOnUiThread { toast("EPG alınamadı: ${ex.message}") }
            }
        }.start()
    }

    private fun epgUrlDialog(m: PlaylistMeta) {
        val et = EditText(this)
        et.hint = "XMLTV adresi (.xml veya .xml.gz)"
        et.setText(m.epgUrl)
        AlertDialog.Builder(this)
            .setTitle("EPG adresi")
            .setView(et)
            .setPositiveButton("Kaydet") { _, _ ->
                m.epgUrl = et.text.toString().trim()
                IptvStore.update(this, m, null)
                metas = IptvStore.playlists(this)
                if (m.epgUrl.isNotEmpty()) updateEpg(m, false)
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    // ---------------- Playlist yönetimi ----------------
    private fun showPlaylists() {
        val names = metas.map { it.name + if (it.id == cur?.id) "  ✓" else "" }.toMutableList()
        names.add("＋ Playlist ekle")
        val dlg = AlertDialog.Builder(this)
            .setTitle("Playlistler (uzun bas: yönet / sil)")
            .setItems(names.toTypedArray()) { _, i -> if (i == metas.size) showAdd() else select(metas[i]) }
            .create()
        dlg.show()
        dlg.listView.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos < metas.size) { dlg.dismiss(); manage(metas[pos]) }
            true
        }
    }

    private fun select(m: PlaylistMeta) {
        cur = metas.firstOrNull { it.id == m.id } ?: m
        IptvStore.setCurrent(this, m.id)
        group = null
        search.setText("")
        loadCurrent()
    }

    private fun manage(m: PlaylistMeta) {
        val opts = arrayOf("Yenile", "Yeniden adlandır", "EPG adresi", "EPG'yi güncelle", "Sil")
        AlertDialog.Builder(this)
            .setTitle(m.name)
            .setItems(opts) { _, i ->
                when (i) {
                    0 -> refreshMeta(m)
                    1 -> rename(m)
                    2 -> epgUrlDialog(m)
                    3 -> updateEpg(m, false)
                    else -> confirmDelete(m)
                }
            }
            .show()
    }

    private fun showMore() {
        val m = cur
        if (m == null) { showAdd(); return }
        manage(m)
    }

    private fun confirmDelete(m: PlaylistMeta) {
        AlertDialog.Builder(this)
            .setTitle("Playlist silinsin mi?")
            .setMessage(m.name)
            .setPositiveButton("Sil") { _, _ ->
                IptvStore.delete(this, m.id)
                metas = IptvStore.playlists(this)
                if (cur?.id == m.id) {
                    cur = metas.firstOrNull()
                    IptvStore.setCurrent(this, cur?.id ?: "")
                    parsed = null
                    loadCurrent()
                }
                toast("Silindi")
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun rename(m: PlaylistMeta) {
        val et = EditText(this)
        et.setText(m.name)
        AlertDialog.Builder(this)
            .setTitle("Yeniden adlandır")
            .setView(et)
            .setPositiveButton("Kaydet") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    m.name = n
                    IptvStore.update(this, m, null)
                    metas = IptvStore.playlists(this)
                    if (cur?.id == m.id) listBtn.text = "$n ▾"
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun refreshMeta(m: PlaylistMeta) {
        if (m.url.isEmpty()) { toast("Dosyadan eklenen liste yenilenemez; yeniden dosya seçerek ekle."); return }
        toast("Liste yenileniyor…")
        Thread {
            try {
                val text = IptvStore.fetch(m.url)
                if (!looksM3u(text)) throw IllegalArgumentException("Geçerli bir M3U listesi değil")
                IptvStore.update(this, m, text)
                metas = IptvStore.playlists(this)
                runOnUiThread { toast("Yenilendi"); if (cur?.id == m.id) loadCurrent() }
            } catch (e: Exception) {
                AppLog.e("Playlist yenileme", e)
                runOnUiThread { toast("Yenilenemedi: ${e.message}") }
            }
        }.start()
    }

    private fun showAdd() {
        AlertDialog.Builder(this)
            .setTitle("Playlist ekle")
            .setItems(arrayOf("Linkten ekle", "Dosyadan ekle (.m3u / .m3u8)")) { _, i ->
                if (i == 0) showLinkDialog("") else pickFile()
            }
            .show()
    }

    private fun showLinkDialog(prefill: String) {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad, pad, 0)
        val name = EditText(this)
        name.hint = "Ad (isteğe bağlı)"
        val url = EditText(this)
        url.hint = "M3U linki (http…)"
        url.setText(prefill)
        box.addView(name)
        box.addView(url)
        AlertDialog.Builder(this)
            .setTitle("Linkten ekle")
            .setView(box)
            .setPositiveButton("Ekle") { _, _ ->
                val u = url.text.toString().trim()
                if (u.startsWith("http")) addFromUrl(name.text.toString().trim(), u) else toast("Geçerli bir http(s) linki gir")
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun addFromUrl(name: String, url: String) {
        toast("Liste indiriliyor…")
        Thread {
            try {
                val text = IptvStore.fetch(url)
                if (!looksM3u(text)) throw IllegalArgumentException("Geçerli bir M3U listesi değil")
                val nm = name.ifBlank { Uri.parse(url).host ?: "Liste" }
                val m = IptvStore.add(this, nm, url, text)
                runOnUiThread {
                    metas = IptvStore.playlists(this)
                    select(m)
                    toast("Eklendi: $nm")
                }
            } catch (e: Exception) {
                AppLog.e("Playlist ekleme", e)
                runOnUiThread { toast("Eklenemedi: ${e.message}") }
            }
        }.start()
    }

    private fun pickFile() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 91
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val u = data?.data
        if (requestCode == 91 && resultCode == RESULT_OK && u != null) importFromUri(u)
    }

    private fun importFromUri(uri: Uri) {
        Thread {
            try {
                val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                if (!looksM3u(text)) throw IllegalArgumentException("Geçerli bir M3U listesi değil")
                val nm = (uri.lastPathSegment ?: "Liste").substringAfterLast('/').substringBeforeLast('.')
                val m = IptvStore.add(this, nm.ifBlank { "Liste" }, "", text)
                runOnUiThread {
                    metas = IptvStore.playlists(this)
                    select(m)
                    toast("Eklendi: ${m.name}")
                }
            } catch (e: Exception) {
                AppLog.e("Playlist içe aktarma", e)
                runOnUiThread { toast("İçe aktarılamadı: ${e.message}") }
            }
        }.start()
    }
}
