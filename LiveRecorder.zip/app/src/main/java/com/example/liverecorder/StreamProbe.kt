package com.example.liverecorder

import java.net.URI

/** type: "hls" | "dash" | "direct" */
data class StreamInfo(val label: String, val score: Int, val type: String = "hls")

/** Bulunan linki analiz eder. Yayın değilse null döner. Arka plan thread'inde çağır. */
object StreamProbe {

    private fun bestVariant(base: String, master: String): String? {
        val lines = master.lines()
        var best = -1L
        var uri: String? = null
        for (i in lines.indices) {
            if (!lines[i].startsWith("#EXT-X-STREAM-INF")) continue
            val bw = Regex("BANDWIDTH=(\\d+)").find(lines[i])?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            val u = lines.drop(i + 1).firstOrNull { it.isNotBlank() && !it.startsWith("#") } ?: continue
            if (bw > best) { best = bw; uri = u.trim() }
        }
        return uri?.let { URI(base).resolve(it).toString() }
    }

    private fun fmt(sec: Double): String =
        if (sec >= 90) "${(sec / 60).toInt()} dk" else "${sec.toInt()} sn"

    private fun directInfo(f: Fetched): StreamInfo {
        val audio = f.contentType.startsWith("audio/")
        val live = f.length <= 0
        val label = buildString {
            if (live) append("CANLI • ") else append("${f.length / 1_000_000} MB • ")
            append(if (audio) "SES" else "VİDEO")
            append(" • ")
            append(f.contentType.substringAfter('/').uppercase())
        }
        val score = if (audio) (if (live) 90 else 40) else (if (live) 85 else 60)
        return StreamInfo(label, score, "direct")
    }

    fun analyze(url: String, headers: Map<String, String>): StreamInfo? {
        val f = QualityProbe.sniff(url, headers)
        if (f.isMedia) return directInfo(f)
        val text = f.text ?: return null
        val isMpd = text.contains("<MPD")
        if (!isMpd && !text.trimStart().startsWith("#EXTM3U")) return null

        var live = false
        var dur = 0.0
        var height = 0
        var master = false
        val kind: String

        if (isMpd) {
            kind = "DASH"
            master = true
            live = text.contains("type=\"dynamic\"")
            height = Regex("height=\"(\\d+)\"").findAll(text).maxOfOrNull { it.groupValues[1].toInt() } ?: 0
            Regex("mediaPresentationDuration=\"([^\"]+)\"").find(text)?.groupValues?.get(1)?.let {
                dur = try { java.time.Duration.parse(it).toMillis() / 1000.0 } catch (e: Exception) { 0.0 }
            }
        } else {
            kind = "HLS"
            var media = text
            if (text.contains("#EXT-X-STREAM-INF")) {
                master = true
                height = Regex("RESOLUTION=\\d+x(\\d+)").findAll(text).maxOfOrNull { it.groupValues[1].toInt() } ?: 0
                val v = bestVariant(url, text)
                media = if (v != null) try { QualityProbe.fetch(v, headers) } catch (e: Exception) { "" } else ""
            }
            if (media.contains("#EXTINF")) {
                live = !media.contains("#EXT-X-ENDLIST")
                dur = Regex("#EXTINF:([\\d.]+)").findAll(media).sumOf { it.groupValues[1].toDoubleOrNull() ?: 0.0 }
            }
        }

        val ad = !live && dur in 0.1..45.0 // kısa, bitmiş akış = büyük olasılıkla reklam
        var score = if (master) 100 else 50
        if (live) score += 50 else if (dur > 0) score += minOf(dur / 60, 60.0).toInt()
        if (ad) score -= 300
        score += height / 10

        val label = buildString {
            if (live) append("CANLI • ") else if (dur > 0) append(fmt(dur)).append(" • ")
            if (height > 0) append("${height}p • ")
            append(kind)
            if (ad) append(" • reklam?")
        }
        return StreamInfo(label, score, if (isMpd) "dash" else "hls")
    }
}
