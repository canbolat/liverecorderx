package com.example.liverecorder

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer

/** Yeniden kodlama yapmadan (hızlı) .ts / benzeri dosyayı MP4 kutusuna alır. */
object Remuxer {
    fun toMp4(src: File, dst: File, audioOnly: Boolean = false) {
        val ex = MediaExtractor()
        ex.setDataSource(src.absolutePath)
        val muxer = MediaMuxer(dst.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        try {
            val map = HashMap<Int, Int>()
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/") || (!audioOnly && mime.startsWith("video/"))) {
                    map[i] = muxer.addTrack(f)
                    ex.selectTrack(i)
                }
            }
            if (map.isEmpty()) throw IOException("Dönüştürülecek parça yok")
            muxer.start()

            val buf = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var base = -1L
            while (true) {
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (base < 0) base = t
                val key = ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0
                info.set(0, size, (t - base).coerceAtLeast(0L), if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                val track = map[ex.sampleTrackIndex]
                if (track != null) muxer.writeSampleData(track, buf, info)
                ex.advance()
            }
            muxer.stop()
        } finally {
            ex.release()
            muxer.release()
        }
    }

    /** Ayrı video ve ses dosyalarını tek MP4'te birleştirir (yeniden kodlama yok). */
    fun mux(video: File, audio: File, out: File) {
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val exs = ArrayList<MediaExtractor>()
        val ids = ArrayList<Int>()
        try {
            for ((f, wantVideo) in listOf(video to true, audio to false)) {
                val ex = MediaExtractor()
                ex.setDataSource(f.absolutePath)
                var sel = -1
                for (i in 0 until ex.trackCount) {
                    val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith(if (wantVideo) "video/" else "audio/")) { sel = i; break }
                }
                if (sel < 0) { ex.release(); throw IOException("Parça bulunamadı: ${f.name}") }
                ex.selectTrack(sel)
                ids.add(muxer.addTrack(ex.getTrackFormat(sel)))
                exs.add(ex)
            }
            muxer.start()
            val base = exs.minOf { it.sampleTime.coerceAtLeast(0L) }
            val buf = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            val active = BooleanArray(exs.size) { true }
            while (true) {
                var idx = -1
                var best = Long.MAX_VALUE
                for (i in exs.indices) {
                    if (!active[i]) continue
                    val t = exs[i].sampleTime
                    if (t < 0) active[i] = false else if (t < best) { best = t; idx = i }
                }
                if (idx < 0) break
                buf.clear()
                val size = exs[idx].readSampleData(buf, 0)
                if (size < 0) { active[idx] = false; continue }
                val key = exs[idx].sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0
                info.set(0, size, (exs[idx].sampleTime - base).coerceAtLeast(0L),
                    if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                muxer.writeSampleData(ids[idx], buf, info)
                exs[idx].advance()
            }
            muxer.stop()
        } finally {
            exs.forEach { it.release() }
            muxer.release()
        }
    }

    /** [startUs, endUs] aralığını yeniden kodlamadan kopyalar (başlangıç, önceki anahtar kareye yuvarlanır). */
    fun trim(ctx: Context, src: Uri, dst: File, startUs: Long, endUs: Long) {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, src, null)
        val muxer = MediaMuxer(dst.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        try {
            val map = HashMap<Int, Int>()
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    map[i] = muxer.addTrack(ex.getTrackFormat(i))
                    ex.selectTrack(i)
                }
            }
            if (map.isEmpty()) throw IOException("Kırpılacak parça yok")
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            muxer.start()
            val buf = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var base = -1L
            var wrote = 0
            while (true) {
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (t > endUs) break
                if (base < 0) base = t
                val key = ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0
                info.set(0, size, (t - base).coerceAtLeast(0L), if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                val track = map[ex.sampleTrackIndex]
                if (track != null) { muxer.writeSampleData(track, buf, info); wrote++ }
                ex.advance()
            }
            if (wrote == 0) throw IOException("Seçilen aralıkta veri yok")
            muxer.stop()
        } finally {
            ex.release()
            muxer.release()
        }
    }
}
