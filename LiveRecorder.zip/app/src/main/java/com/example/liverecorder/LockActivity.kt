package com.example.liverecorder

import android.app.Activity
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** PIN (ve isteğe bağlı parmak izi) ile açılan kilit ekranı. */
class LockActivity : Activity() {

    private var fails = 0
    private lateinit var pin: EditText
    private lateinit var btn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeUtil.apply(this)
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "Live Recorder kilitli"
        title.textSize = 20f
        title.gravity = Gravity.CENTER
        root.addView(title)

        pin = EditText(this)
        pin.hint = "PIN"
        pin.gravity = Gravity.CENTER
        pin.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        pin.imeOptions = EditorInfo.IME_ACTION_DONE
        pin.setOnEditorActionListener { _, _, _ -> check(); true }
        root.addView(pin, LinearLayout.LayoutParams(-1, -2))

        btn = Button(this)
        btn.text = "Aç"
        btn.setOnClickListener { check() }
        root.addView(btn, LinearLayout.LayoutParams(-1, -2))

        if (Prefs.lockMode == 2 && bioAvailable()) {
            val bio = Button(this)
            bio.text = "Parmak izi ile aç"
            bio.setOnClickListener { promptBio() }
            root.addView(bio, LinearLayout.LayoutParams(-1, -2))
            setContentView(root)
            promptBio()
        } else {
            setContentView(root)
        }
    }

    @Suppress("DEPRECATION")
    private fun bioAvailable(): Boolean = try {
        getSystemService(BiometricManager::class.java).canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
    } catch (e: Exception) {
        false
    }

    private fun promptBio() {
        try {
            val prompt = BiometricPrompt.Builder(this)
                .setTitle("Live Recorder")
                .setNegativeButton("PIN kullan", mainExecutor) { _, _ -> }
                .build()
            prompt.authenticate(CancellationSignal(), mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    done()
                }
            })
        } catch (e: Exception) {
            AppLog.e("Parmak izi", e)
        }
    }

    private fun check() {
        if (Prefs.checkPin(pin.text.toString())) {
            done()
            return
        }
        fails++
        pin.setText("")
        Toast.makeText(this, "Yanlış PIN", Toast.LENGTH_SHORT).show()
        if (fails >= 5) {
            btn.isEnabled = false
            pin.isEnabled = false
            Toast.makeText(this, "Çok fazla deneme, 30 sn bekle", Toast.LENGTH_LONG).show()
            Handler(Looper.getMainLooper()).postDelayed({
                btn.isEnabled = true
                pin.isEnabled = true
                fails = 0
            }, 30_000)
        }
    }

    private fun done() {
        LockGate.unlock()
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        LockGate.lock()
        moveTaskToBack(true)
        finish()
    }
}
