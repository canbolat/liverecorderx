package com.example.liverecorder

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaMuxer
import okhttp3.OkHttpClient
import okhttp3.Request
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.net.URI
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.time.Instant
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.xml.parsers.DocumentBuilderFactory

/**
 * DASH (mpd) kaydedici. Desteklenen: SegmentTemplate (+SegmentTimeline veya sabit duration),
 * statik ve canlı (dynamic) yayın, ilk Period. Video ve ses ayrı indirilir, MediaMuxer ile birleştirilir.
 * Desteklenmeyen: SegmentBase/SegmentList, çoklu Period, DRM (ContentProtection).
 */
class DashRecorder(
    private val url: String,
    private val headers: Map<String, String>,
    private val dir: File,
    private val bandwidth: Long,
    private val audioOnly: Boolean,
    private val onStatus: (String) -> Unit
) : Recorder {

    @Volatile private var running = true
    override fun stop() { running = false }

    private val extraFiles = ArrayList<File>()
    override val extras: List<File> get() = extraFiles

    private fun score(kind: String, bw: Long, lang: String): Long {
        var s = if (kind == "video" && bandwidth > 0) -Math.abs(bw - bandwidth) else bw
        if (kind == "audio") {
            val pref = Prefs.audioLang.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            if (pref.any { lang.lowercase().startsWith(it) }) s += 1_000_000_000_000L
        }
        return s
    }

    /** Tek dosyalık (BaseURL) altyazı akışını indirir. Parçalı altyazılar desteklenmez. */
    private fun grabSubtitle(mpd: Element, period: Element, stamp: String): File? {
        if (!Prefs.saveSubs) return null
        val prefs = Prefs.subLang.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        val b1 = baseOf(period, baseOf(mpd, url))
        for (a in kids(period, "AdaptationSet")) {
            val mime = a.getAttribute("mimeType").ifEmpty {
                kids(a, "Representation").firstOrNull()?.getAttribute("mimeType") ?: ""
            }
            val isText = a.getAttribute("contentType") == "text" || mime.startsWith("text/") ||
                mime.contains("ttml") || mime.contains("vtt")
            if (!isText) continue
            val lang = a.getAttribute("lang").lowercase()
            if (prefs.isNotEmpty() && prefs.none { lang.startsWith(it) }) continue
            val b2 = baseOf(a, b1)
            for (r in kids(a, "Representation")) {
                if (kids(r, "BaseURL").isEmpty()) continue
                val u = baseOf(r, b2)
                val e = u.substringBefore('?').substringAfterLast('.', "").lowercase()
                val ext = when (e) { "vtt", "srt", "ttml" -> e; "xml" -> "ttml"; else -> "vtt" }
                val f = File(dir, "kayit_$stamp.${lang.ifEmpty { "sub" }}.$ext")
                val bytes = client.newCall(req(u)).execute().use {
                    if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
                    it.body!!.bytes()
                }
                f.writeBytes(bytes)
                return f
            }
        }
        return null
    }

    private val client = Http.client(15, 30)
    private val ua = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"

    private fun req(u: String) = Request.Builder().url(u)
        .header("User-Agent", ua)
        .apply { headers.forEach { (k, v) -> header(k, v) } }
        .build()

    private fun fetchText(u: String): String =
        client.newCall(req(u)).execute().use {
            if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
            it.body!!.string()
        }

    private fun download(u: String, out: OutputStream): Long =
        client.newCall(req(u)).execute().use {
            if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
            it.body!!.byteStream().copyTo(out)
        }

    private fun abs(base: String, ref: String): String = URI(base).resolve(ref).toString()

    private class Track(val kind: String, val repId: String, val bw: Long, val tpl: Element, val base: String, val lang: String)
    private class State(val file: File) {
        val out = FileOutputStream(file)
        val seen = HashSet<String>()
        var init = false
        var n = 0
    }

    // ---- XML yardımcıları ----
    private fun kids(e: Element, name: String): List<Element> {
        val l = ArrayList<Element>()
        val c = e.childNodes
        for (i in 0 until c.length) {
            val n = c.item(i)
            if (n is Element && n.nodeName.substringAfter(':') == name) l.add(n)
        }
        return l
    }

    private fun baseOf(e: Element, parent: String): String {
        val b = kids(e, "BaseURL").firstOrNull()?.textContent?.trim()
        return if (b.isNullOrEmpty()) parent else abs(parent, b)
    }

    private fun parse(text: String): Element = try {
        DocumentBuilderFactory.newInstance().newDocumentBuilder()
            .parse(ByteArrayInputStream(text.toByteArray())).documentElement
    } catch (e: Exception) {
        throw IOException("MPD okunamadı: ${e.message}")
    }

    private fun checkDrm(e: Element) {
        for (cp in kids(e, "ContentProtection")) {
            if (!cp.getAttribute("schemeIdUri").contains("mp4protection")) {
                throw IOException("DRM korumalı yayın desteklenmiyor")
            }
        }
    }

    // ---- Track seçimi: her tür için en yüksek bant genişliği ----
    private fun pickTracks(mpd: Element, period: Element): List<Track> {
        val b1 = baseOf(period, baseOf(mpd, url))
        val best = HashMap<String, Track>()
        for (a in kids(period, "AdaptationSet")) {
            checkDrm(a)
            val b2 = baseOf(a, b1)
            for (r in kids(a, "Representation")) {
                checkDrm(r)
                val mime = r.getAttribute("mimeType").ifEmpty { a.getAttribute("mimeType") }
                val ct = a.getAttribute("contentType").ifEmpty { mime.substringBefore('/') }
                val kind = when {
                    ct.startsWith("video") -> "video"
                    ct.startsWith("audio") -> "audio"
                    else -> continue
                }
                val tpl = kids(r, "SegmentTemplate").firstOrNull()
                    ?: kids(a, "SegmentTemplate").firstOrNull() ?: continue
                val bw = r.getAttribute("bandwidth").toLongOrNull() ?: 0L
                val cur = best[kind]
                if (cur == null || score(kind, bw, a.getAttribute("lang")) > score(kind, cur.bw, cur.lang)) {
                    best[kind] = Track(kind, r.getAttribute("id"), bw, tpl, baseOf(r, b2), a.getAttribute("lang"))
                }
            }
        }
        if (best.isEmpty()) throw IOException("Desteklenen akış bulunamadı (SegmentTemplate yok)")
        return listOfNotNull(best["video"], best["audio"])
    }

    // ---- Şablon doldurma ----
    private fun fill(tpl: String, t: Track, number: Long?, time: Long?): String {
        val s = tpl.replace("\$RepresentationID\$", t.repId).replace("\$Bandwidth\$", t.bw.toString())
        return Regex("""\$(Number|Time)(%0(\d+)d)?\$""").replace(s) { m ->
            val v = if (m.groupValues[1] == "Number") number else time
            (v ?: 0L).toString().padStart(m.groupValues[3].toIntOrNull() ?: 0, '0')
        }.replace("\$\$", "\$")
    }

    private fun segmentUrls(t: Track, dynamic: Boolean, mpd: Element, totalSec: Double?): List<String> {
        val tpl = t.tpl
        val media = tpl.getAttribute("media")
        val ts = tpl.getAttribute("timescale").toLongOrNull() ?: 1L
        val start = tpl.getAttribute("startNumber").toLongOrNull() ?: 1L
        val res = ArrayList<String>()

        val tl = kids(tpl, "SegmentTimeline").firstOrNull()
        if (tl != null) {
            var time = 0L
            var num = start
            for (s in kids(tl, "S")) {
                s.getAttribute("t").toLongOrNull()?.let { time = it }
                val d = s.getAttribute("d").toLong()
                val r = s.getAttribute("r").toIntOrNull()?.coerceAtLeast(0) ?: 0
                repeat(r + 1) {
                    res.add(abs(t.base, fill(media, t, num, time)))
                    time += d
                    num++
                }
            }
            return res
        }

        val dur = tpl.getAttribute("duration").toLongOrNull() ?: throw IOException("Segment süresi yok")
        val segSec = dur.toDouble() / ts
        if (!dynamic) {
            val total = totalSec ?: throw IOException("Yayın süresi bilinmiyor")
            val count = Math.ceil(total / segSec).toLong()
            for (i in 0 until count) res.add(abs(t.base, fill(media, t, start + i, null)))
        } else {
            val ast = Instant.parse(mpd.getAttribute("availabilityStartTime"))
            val elapsed = (System.currentTimeMillis() - ast.toEpochMilli()) / 1000.0
            val latest = start + Math.floor(elapsed / segSec).toLong() - 2
            for (n in (latest - 3)..latest) {
                if (n >= start) res.add(abs(t.base, fill(media, t, n, null)))
            }
        }
        return res
    }

    // ---- Ana döngü ----
    override fun run(): File {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val states = HashMap<String, State>()
        var outageSince = 0L
        var lastTotal = -1
        var lastMpd: Element? = null
        var lastPeriod: Element? = null
        var lastNewAt = System.currentTimeMillis()
        val outageLimit = 10 * 60_000L
        val idleLimit = 90_000L

        try {
            while (running) {
                var mpd: Element? = null
                try {
                    mpd = parse(fetchText(url))
                    if (outageSince != 0L) {
                        outageSince = 0L
                        lastNewAt = System.currentTimeMillis()
                    }
                } catch (e: IOException) {
                    if (states.isEmpty()) throw e
                    val nowMs = System.currentTimeMillis()
                    if (outageSince == 0L) outageSince = nowMs
                    if (nowMs - outageSince > outageLimit) break
                    onStatus("Bağlantı koptu, yeniden deneniyor…")
                }

                var dynamic = false
                var sleepMs = 2000L
                if (mpd != null) {
                    dynamic = mpd.getAttribute("type") == "dynamic"
                    val period = kids(mpd, "Period").firstOrNull() ?: throw IOException("Period yok")
                    lastMpd = mpd
                    lastPeriod = period
                    val totalSec = listOf(period.getAttribute("duration"), mpd.getAttribute("mediaPresentationDuration"))
                        .firstOrNull { it.isNotEmpty() }
                        ?.let { java.time.Duration.parse(it).toMillis() / 1000.0 }

                    for (t in pickTracks(mpd, period).filter { !audioOnly || it.kind == "audio" }) {
                        val st = states.getOrPut(t.kind) { State(File(dir, "tmp_${stamp}_${t.kind}.mp4")) }
                        if (!st.init) {
                            val initTpl = t.tpl.getAttribute("initialization")
                            if (initTpl.isNotEmpty()) download(abs(t.base, fill(initTpl, t, null, null)), st.out)
                            st.init = true
                        }
                        for (u in segmentUrls(t, dynamic, mpd, totalSec)) {
                            if (!running) break
                            if (u in st.seen) continue
                            try {
                                download(u, st.out)
                                st.seen.add(u)
                                st.n++
                            } catch (_: IOException) { /* sonra tekrar denenir */ }
                        }
                        val segDur = (t.tpl.getAttribute("duration").toLongOrNull() ?: 0L) * 1000L /
                            (t.tpl.getAttribute("timescale").toLongOrNull() ?: 1L)
                        if (segDur > 0) sleepMs = minOf(sleepMs.coerceAtLeast(500L), maxOf(segDur / 2, 500L))
                    }
                    onStatus("Kaydediliyor: " + states.entries.joinToString(" • ") { "${it.key} ${it.value.n}" })
                    val total = states.values.sumOf { it.n }
                    val nowMs = System.currentTimeMillis()
                    if (total != lastTotal) {
                        lastTotal = total
                        lastNewAt = nowMs
                    } else if (dynamic && outageSince == 0L && nowMs - lastNewAt > idleLimit) {
                        break
                    }
                    if (!dynamic) break
                }
                try { Thread.sleep(sleepMs) } catch (_: InterruptedException) { break }
            }
        } finally {
            states.values.forEach { try { it.out.close() } catch (_: IOException) {} }
        }

        val lm = lastMpd
        val lp = lastPeriod
        if (lm != null && lp != null) {
            try { grabSubtitle(lm, lp, stamp)?.let { extraFiles.add(it) } } catch (_: Exception) {}
        }
        val v = states["video"]?.file
        val a = states["audio"]?.file
        if (v == null && a == null) throw IOException("Kayıt boş")

        val out = File(dir, "kayit_$stamp.mp4")
        if (v != null && a != null) {
            onStatus("Video ve ses birleştiriliyor…")
            try {
                mux(v, a, out)
                v.delete(); a.delete()
                return out
            } catch (e: Exception) {
                out.delete()
                val vv = File(dir, "kayit_${stamp}_video.mp4")
                v.renameTo(vv)
                a.renameTo(File(dir, "kayit_${stamp}_audio.mp4"))
                return vv // ses dosyası uygulama klasöründe ayrı kalır
            }
        }
        (v ?: a)!!.renameTo(out)
        return out
    }

    // ---- Video + ses birleştirme (fMP4 -> MP4) ----
    private fun mux(video: File, audio: File, out: File) {
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val exs = ArrayList<MediaExtractor>()
        val ids = ArrayList<Int>()
        try {
            for (f in listOf(video, audio)) {
                val ex = MediaExtractor()
                ex.setDataSource(f.absolutePath)
                ex.selectTrack(0)
                ids.add(muxer.addTrack(ex.getTrackFormat(0)))
                exs.add(ex)
            }
            muxer.start()
            val base = exs.minOf { it.sampleTime.coerceAtLeast(0L) }
            val buf = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            val active = BooleanArray(exs.size) { true }
            while (true) {
                var idx = -1
                var best = Long.MAX_VALUE
                for (i in exs.indices) {
                    if (!active[i]) continue
                    val t = exs[i].sampleTime
                    if (t < 0) active[i] = false else if (t < best) { best = t; idx = i }
                }
                if (idx < 0) break
                buf.clear()
                val size = exs[idx].readSampleData(buf, 0)
                if (size < 0) { active[idx] = false; continue }
                val key = exs[idx].sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0
                info.set(0, size, exs[idx].sampleTime - base, if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                muxer.writeSampleData(ids[idx], buf, info)
                exs[idx].advance()
            }
            muxer.stop()
        } finally {
            exs.forEach { it.release() }
            muxer.release()
        }
    }
}
