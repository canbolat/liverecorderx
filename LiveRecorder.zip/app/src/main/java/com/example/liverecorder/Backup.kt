package com.example.liverecorder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Ayarları, yer imlerini ve izleme listesini JSON dosyasına aktarır / geri yükler. */
object Backup {
    fun export(ctx: Context): String {
        val o = JSONObject()
        val s = JSONObject()
        for ((k, v) in Prefs.p.all) {
            if (v != null && !k.startsWith("lib_history") && k != "pinHash" && k != "pinSalt" && k != "lockMode") s.put(k, v)
        }
        o.put("version", 1)
        o.put("settings", s)
        val w = ctx.getSharedPreferences("watch", Context.MODE_PRIVATE).getString("list", "[]") ?: "[]"
        o.put("watches", JSONArray(w))
        return o.toString(2)
    }

    fun import(ctx: Context, json: String) {
        val o = JSONObject(json)
        val s = o.getJSONObject("settings")
        val ed = Prefs.p.edit()
        s.keys().forEach { k ->
            when (val v = s.get(k)) {
                is Boolean -> ed.putBoolean(k, v)
                is Int -> ed.putInt(k, v)
                is Long -> ed.putInt(k, v.toInt())
                is String -> ed.putString(k, v)
                else -> {}
            }
        }
        ed.apply()
        val w = o.optJSONArray("watches")
        if (w != null) {
            ctx.getSharedPreferences("watch", Context.MODE_PRIVATE).edit().putString("list", w.toString()).apply()
            Watcher.rearmAll(ctx)
        }
    }
}
