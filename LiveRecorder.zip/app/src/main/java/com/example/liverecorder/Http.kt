package com.example.liverecorder

import android.net.Uri
import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.dnsoverhttps.DnsOverHttps
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.TimeUnit

/** Tüm ağ istemcileri buradan çıkar: proxy ve şifreli DNS ayarları uygulanır. */
object Http {
    fun client(connectSec: Long, readSec: Long): OkHttpClient {
        val b = OkHttpClient.Builder()
            .connectTimeout(connectSec, TimeUnit.SECONDS)
            .readTimeout(readSec, TimeUnit.SECONDS)
        proxyOf(Prefs.proxy)?.let { b.proxy(it) }
        when (Prefs.dns) {
            1 -> b.dns(doh("https://1.1.1.1/dns-query"))
            2 -> b.dns(doh("https://8.8.8.8/dns-query"))
        }
        return b.build()
    }

    private fun doh(u: String): Dns =
        DnsOverHttps.Builder()
            .client(OkHttpClient.Builder().build())
            .url(u.toHttpUrl())
            .includeIPv6(false)
            .build()

    private fun proxyOf(s: String): Proxy? {
        val t = s.trim()
        if (t.isEmpty()) return null
        return try {
            val uri = Uri.parse(t)
            val host = uri.host ?: return null
            val port = if (uri.port > 0) uri.port else 8080
            val type = if (uri.scheme?.startsWith("socks") == true) Proxy.Type.SOCKS else Proxy.Type.HTTP
            Proxy(type, InetSocketAddress.createUnresolved(host, port))
        } catch (e: Exception) {
            null
        }
    }
}
