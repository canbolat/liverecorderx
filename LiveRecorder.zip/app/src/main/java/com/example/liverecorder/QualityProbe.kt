package com.example.liverecorder

import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

data class Quality(val label: String, val bandwidth: Long)

class Fetched(val contentType: String, val text: String?, val isMedia: Boolean, val length: Long)

/** m3u8 master playlist veya mpd içindeki video kalitelerini listeler. Arka plan thread'inde çağır. */
object QualityProbe {
    private val client = Http.client(10, 15)

    fun fetch(url: String, headers: Map<String, String>): String {
        val rb = Request.Builder().url(url)
        headers.forEach { (k, v) -> rb.header(k, v) }
        return client.newCall(rb.build()).execute().use {
            if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
            it.body!!.string()
        }
    }

    /** Yanıt başlıklarına bakar: doğrudan ses/video akışı mı, yoksa playlist/manifest metni mi? */
    fun sniff(url: String, headers: Map<String, String>, peek: Long = 2_000_000): Fetched {
        val rb = Request.Builder().url(url).header("Icy-MetaData", "0")
        headers.forEach { (k, v) -> rb.header(k, v) }
        client.newCall(rb.build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val ct = r.header("Content-Type")?.substringBefore(';')?.trim()?.lowercase() ?: ""
            val len = r.header("Content-Length")?.toLongOrNull() ?: -1L
            val media = !ct.contains("mpegurl") &&
                (ct.startsWith("audio/") || ct.startsWith("video/") || ct == "application/ogg")
            if (media) return Fetched(ct, null, true, len)
            return Fetched(ct, r.peekBody(peek).string(), false, len)
        }
    }

    private fun attr(tag: String, name: String): String? =
        Regex("\\b$name=\"([^\"]*)\"").find(tag)?.groupValues?.get(1)

    fun probe(url: String, headers: Map<String, String>): List<Quality> {
        val text = fetch(url, headers)
        val res = LinkedHashMap<Long, Quality>()

        if (text.contains("<MPD")) {
            Regex("<Representation[^>]*>").findAll(text).forEach { m ->
                val tag = m.value
                val bw = attr(tag, "bandwidth")?.toLongOrNull() ?: return@forEach
                val h = attr(tag, "height") ?: return@forEach // yüksekliği olmayan = ses
                res[bw] = Quality("${h}p • ${bw / 1000} kbps", bw)
            }
        } else {
            text.lines().filter { it.startsWith("#EXT-X-STREAM-INF") }.forEach { l ->
                val bw = Regex("BANDWIDTH=(\\d+)").find(l)?.groupValues?.get(1)?.toLongOrNull() ?: return@forEach
                val h = Regex("RESOLUTION=\\d+x(\\d+)").find(l)?.groupValues?.get(1)
                res[bw] = Quality(if (h != null) "${h}p • ${bw / 1000} kbps" else "${bw / 1000} kbps", bw)
            }
        }
        return res.values.sortedByDescending { it.bandwidth }
    }
}
