package com.example.liverecorder

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager

/** Uygulama kilidi durumu: arka plandan 30 sn içinde dönülürse tekrar sormaz. */
object LockGate {
    private const val GRACE_MS = 30_000L
    @Volatile var unlocked = false
    private var started = 0
    private var lastLeft = 0L

    fun needsUnlock(): Boolean {
        if (Prefs.lockMode == 0 || Prefs.pinHash.isEmpty()) return false
        if (!unlocked) return true
        return started == 0 && System.currentTimeMillis() - lastLeft > GRACE_MS
    }

    fun unlock() { unlocked = true }
    fun lock() { unlocked = false }
    fun onStart() { started++ }
    fun onStop() {
        started--
        if (started <= 0) { started = 0; lastLeft = System.currentTimeMillis() }
    }
}

/** Kilit açılmadan içeriği göstermeyen temel ekran; kilit açıkken görüntü yakalamayı da engeller. */
open class LockedActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Prefs.lockMode != 0) {
            window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    override fun onStart() {
        super.onStart()
        if (LockGate.needsUnlock()) startActivity(Intent(this, LockActivity::class.java))
        LockGate.onStart()
    }

    override fun onStop() {
        LockGate.onStop()
        super.onStop()
    }
}
