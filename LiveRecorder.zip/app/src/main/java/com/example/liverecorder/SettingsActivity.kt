package com.example.liverecorder

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : LockedActivity() {

    private lateinit var box: LinearLayout
    private var pad = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeUtil.apply(this)
        super.onCreate(savedInstanceState)
        pad = (14 * resources.displayMetrics.density).toInt()
        val sv = ScrollView(this)
        sv.fitsSystemWindows = true
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad, pad, pad)
        sv.addView(box)
        setContentView(sv)
        build()
    }

    private fun header(t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 13f
        tv.setPadding(0, pad * 2, 0, 0)
        box.addView(tv)
    }

    private fun switchRow(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val s = Switch(this)
        s.text = title
        s.textSize = 16f
        s.isChecked = value
        s.setPadding(0, pad, 0, pad)
        s.setOnCheckedChangeListener { _, v -> onChange(v) }
        box.addView(s)
    }

    private fun choiceRow(title: String, labels: Array<String>, current: Int, onPick: (Int) -> Unit) {
        val tv = TextView(this)
        tv.textSize = 16f
        tv.setPadding(0, pad, 0, pad)
        tv.text = "$title: ${labels[current.coerceIn(0, labels.size - 1)]}"
        tv.setOnClickListener {
            AlertDialog.Builder(this).setTitle(title).setItems(labels) { _, i ->
                onPick(i)
                tv.text = "$title: ${labels[i]}"
            }.show()
        }
        box.addView(tv)
    }

    private fun textRow(title: String, value: String, onSave: (String) -> Unit) {
        val tv = TextView(this)
        tv.textSize = 16f
        tv.setPadding(0, pad, 0, pad)
        var cur = value
        fun show() { tv.text = "$title\n${if (cur.isEmpty()) "(boş)" else cur}" }
        show()
        tv.setOnClickListener {
            val et = EditText(this)
            et.setText(cur)
            AlertDialog.Builder(this).setTitle(title).setView(et)
                .setPositiveButton("Kaydet") { _, _ ->
                    cur = et.text.toString().trim()
                    onSave(cur)
                    show()
                }
                .setNegativeButton("İptal", null)
                .show()
        }
        box.addView(tv)
    }

    private fun actionRow(title: String, sub: String, onClick: () -> Unit) {
        val tv = TextView(this)
        tv.textSize = 16f
        tv.setPadding(0, pad, 0, pad)
        tv.text = if (sub.isEmpty()) title else "$title\n$sub"
        tv.setOnClickListener { onClick() }
        box.addView(tv)
    }

    private fun batteryExempt(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    private fun askNewPin(done: (Boolean) -> Unit) {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        et.hint = "4-8 haneli PIN"
        AlertDialog.Builder(this)
            .setTitle("PIN belirle")
            .setView(et)
            .setPositiveButton("Kaydet") { _, _ ->
                val p = et.text.toString()
                if (p.length in 4..8) {
                    Prefs.setPin(p)
                    done(true)
                } else {
                    Toast.makeText(this, "PIN 4-8 hane olmalı", Toast.LENGTH_SHORT).show()
                    done(false)
                }
            }
            .setNegativeButton("İptal") { _, _ -> done(false) }
            .setOnCancelListener { done(false) }
            .show()
    }

    private fun updateEngine() {
        Toast.makeText(this, "Güncelleniyor, bekle…", Toast.LENGTH_SHORT).show()
        Thread {
            val msg = try {
                SocialRecorder.ensureInit(this)
                val st = com.yausername.youtubedl_android.YoutubeDL.updateYoutubeDL(
                    this, com.yausername.youtubedl_android.YoutubeDL.UpdateChannel.STABLE
                )
                val ver = com.yausername.youtubedl_android.YoutubeDL.version(this) ?: "?"
                if (st == com.yausername.youtubedl_android.YoutubeDL.UpdateStatus.DONE) "Güncellendi: $ver"
                else "Zaten güncel: $ver"
            } catch (e: Exception) {
                AppLog.e("yt-dlp güncelleme", e)
                "Güncellenemedi: ${e.message}"
            }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }

    private fun doExport() {
        try {
            val f = java.io.File(cacheDir, "live_recorder_yedek.json")
            f.writeText(Backup.export(this))
            val s = MediaSaver.saveWithUri(this, f)
            Toast.makeText(this, "Yedek kaydedildi: ${s.path}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            AppLog.e("Yedekleme", e)
            Toast.makeText(this, "Yedeklenemedi: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun doImport() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 77
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val u = data?.data
        if (requestCode != 77 || resultCode != RESULT_OK || u == null) return
        try {
            val text = contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }
            Backup.import(this, text)
            Toast.makeText(this, "Ayarlar geri yüklendi", Toast.LENGTH_LONG).show()
            recreate()
        } catch (e: Exception) {
            AppLog.e("Geri yükleme", e)
            Toast.makeText(this, "Geri yüklenemedi: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun build() {
        header("GÖRÜNÜM")
        switchRow("Karanlık mod", Prefs.dark) { Prefs.dark = it; recreate() }

        header("KAYIT")
        switchRow("Yalnızca Wi-Fi'da kaydet", Prefs.wifiOnly) { Prefs.wifiOnly = it }
        val conc = intArrayOf(1, 2, 3, 4)
        choiceRow("Aynı anda kayıt", arrayOf("1", "2", "3", "4"), conc.indexOf(Prefs.maxConcurrent)) {
            Prefs.maxConcurrent = conc[it]
        }
        val split = intArrayOf(0, 15, 30, 60, 120)
        choiceRow("Kaydı böl", arrayOf("Kapalı", "15 dk", "30 dk", "1 saat", "2 saat"),
            split.indexOf(Prefs.splitMin)) { Prefs.splitMin = split[it] }
        val free = intArrayOf(200, 500, 1000, 2000)
        choiceRow("Boş alan bu değerin altına inerse durdur", arrayOf("200 MB", "500 MB", "1 GB", "2 GB"),
            free.indexOf(Prefs.minFreeMb)) { Prefs.minFreeMb = free[it] }
        val watch = intArrayOf(2, 5, 15)
        choiceRow("Yayın izleme aralığı", arrayOf("2 dk", "5 dk", "15 dk"),
            watch.indexOf(Prefs.watchMin)) { Prefs.watchMin = watch[it] }

        actionRow(
            "Pil optimizasyonunu kapat",
            if (batteryExempt()) "Kapalı (uzun kayıtlar için iyi)" else "Açık: dokun ve izin ver (uzun kayıtlar kesilmesin)"
        ) {
            if (!batteryExempt()) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            }
        }
        switchRow("Panodaki yayın linkini algıla", Prefs.clipWatch) { Prefs.clipWatch = it }
        switchRow("HLS reklam bölümlerini atla", Prefs.skipAds) { Prefs.skipAds = it }

        header("TEMİZLİK")
        val days = intArrayOf(0, 7, 30, 90)
        choiceRow("Eski kayıtları otomatik sil", arrayOf("Kapalı", "7 günden eski", "30 günden eski", "90 günden eski"),
            days.indexOf(Prefs.autoDeleteDays)) { Prefs.autoDeleteDays = days[it] }
        val gbs = intArrayOf(0, 5, 10, 20)
        choiceRow("Toplam boyut sınırı (aşarsa en eski silinir)", arrayOf("Kapalı", "5 GB", "10 GB", "20 GB"),
            gbs.indexOf(Prefs.maxTotalGb)) { Prefs.maxTotalGb = gbs[it] }

        header("ALTYAZI VE SES")
        switchRow("Altyazıyı kaydet", Prefs.saveSubs) { Prefs.saveSubs = it }
        textRow("Altyazı dili (ör. tr,en)", Prefs.subLang) { Prefs.subLang = it }
        textRow("Ses dili (ör. tr)", Prefs.audioLang) { Prefs.audioLang = it }

        header("TARAYICI")
        switchRow("Reklam engelle", Prefs.adBlock) { Prefs.adBlock = it }
        textRow("Ek engellenecek alan adları (virgülle)", Prefs.adHosts) { Prefs.adHosts = it }

        header("SOSYAL MEDYA İNDİRİCİ")
        switchRow("Paylaşılan sosyal medya linkini hemen indir (soru sorma)", Prefs.quickShare) { Prefs.quickShare = it }
        val hs = intArrayOf(0, 1080, 720, 480)
        choiceRow("Hızlı indirme kalitesi", arrayOf("En iyi", "1080p'ye kadar", "720p'ye kadar", "480p'ye kadar"),
            hs.indexOf(Prefs.socialHeight)) { Prefs.socialHeight = hs[it] }
        actionRow(
            "İndirici motorunu güncelle (yt-dlp)",
            "Siteler değişince indirme bozulursa güncelle. İnternet gerekir."
        ) { updateEngine() }

        header("GÜVENLİK")
        choiceRow("Uygulama kilidi", arrayOf("Kapalı", "PIN", "PIN + parmak izi"), Prefs.lockMode) { i ->
            if (i == 0 || Prefs.pinHash.isNotEmpty()) {
                Prefs.lockMode = i
                LockGate.unlock()
            } else {
                askNewPin { ok ->
                    if (ok) { Prefs.lockMode = i; LockGate.unlock() }
                    build()
                }
            }
        }
        actionRow("PIN değiştir", "Kilit açıkken kayıtlar, geçmiş ve ekran görüntüsü korunur") { askNewPin { } }

        header("YEDEK")
        actionRow("Ayarları yedekle", "Ayarlar, yer imleri ve izleme listesi Download/LiveRecorder klasörüne JSON olarak kaydedilir") { doExport() }
        actionRow("Yedekten geri yükle", "Daha önce aldığın JSON dosyasını seç") { doImport() }

        header("AĞ (kayıt ve analiz istekleri)")
        textRow("Proxy (ör. socks5://host:1080 veya http://host:8080)", Prefs.proxy) { Prefs.proxy = it }
        choiceRow("Şifreli DNS", arrayOf("Sistem", "Cloudflare (1.1.1.1)", "Google (8.8.8.8)"), Prefs.dns) {
            Prefs.dns = it
        }
        val note = TextView(this)
        note.textSize = 12f
        note.setPadding(0, pad, 0, 0)
        note.text = "Proxy ve DNS ayarı kayıt/analiz isteklerinde geçerlidir; sayfa gezinmesi sistem ayarını kullanır."
        box.addView(note)
    }
}
