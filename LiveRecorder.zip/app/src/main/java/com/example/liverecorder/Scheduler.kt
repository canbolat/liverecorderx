package com.example.liverecorder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

data class Sched(
    val id: Int,
    val whenMs: Long,
    val url: String,
    val headers: Map<String, String>,
    val bandwidth: Long,
    val durMin: Int,
    val type: String = "",
    val audioOnly: Boolean = false,
    val title: String = ""
)

/** Zamanlı kayıtları SharedPreferences'ta saklar; alarm kurar/iptal eder; yeniden başlatmada geri yükler. */
object Scheduler {
    private const val PREF = "sched"
    private const val KEY = "list"

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun all(c: Context): List<Sched> {
        val arr = try { JSONArray(prefs(c).getString(KEY, "[]")) } catch (e: Exception) { JSONArray() }
        val res = ArrayList<Sched>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val hj = o.getJSONObject("h")
            val h = HashMap<String, String>()
            hj.keys().forEach { k -> h[k] = hj.getString(k) }
            res.add(Sched(o.getInt("id"), o.getLong("t"), o.getString("u"), h, o.getLong("b"), o.getInt("d"),
                o.optString("ty", ""), o.optBoolean("ao", false), o.optString("tt", "")))
        }
        return res.sortedBy { it.whenMs }
    }

    private fun write(c: Context, list: List<Sched>) {
        val arr = JSONArray()
        list.forEach { s ->
            arr.put(
                JSONObject()
                    .put("id", s.id).put("t", s.whenMs).put("u", s.url)
                    .put("h", JSONObject(s.headers)).put("b", s.bandwidth).put("d", s.durMin)
                    .put("ty", s.type).put("ao", s.audioOnly).put("tt", s.title)
            )
        }
        prefs(c).edit().putString(KEY, arr.toString()).apply()
    }

    private fun arm(c: Context, s: Sched) {
        val i = Intent(c, ScheduleReceiver::class.java)
            .putExtra("sched_id", s.id)
            .putExtra("url", s.url)
            .putExtra("headers", HashMap(s.headers))
            .putExtra("bandwidth", s.bandwidth)
            .putExtra("duration", s.durMin)
            .putExtra("type", s.type)
            .putExtra("audioOnly", s.audioOnly)
            .putExtra("title", s.title)
        val pi = PendingIntent.getBroadcast(c, s.id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        c.getSystemService(AlarmManager::class.java)
            .setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, s.whenMs, pi)
    }

    fun add(c: Context, s: Sched) {
        write(c, all(c) + s)
        arm(c, s)
    }

    /** Tetiklenen kaydı listeden düşer (alarm zaten çalıştı). */
    fun remove(c: Context, id: Int) {
        write(c, all(c).filter { it.id != id })
    }

    fun cancel(c: Context, id: Int) {
        val pi = PendingIntent.getBroadcast(
            c, id, Intent(c, ScheduleReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
        )
        if (pi != null) {
            c.getSystemService(AlarmManager::class.java).cancel(pi)
            pi.cancel()
        }
        remove(c, id)
    }

    /** Telefon yeniden başlayınca: gelecekteki kayıtların alarmlarını tekrar kur, geçmişleri sil. */
    fun rearmAll(c: Context) {
        val now = System.currentTimeMillis()
        val future = all(c).filter { it.whenMs > now }
        write(c, future)
        val am = c.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) return
        future.forEach { arm(c, it) }
    }
}
