package com.example.liverecorder

import android.content.Context
import android.content.Intent
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

class Channel(
    val name: String,
    val url: String,
    val group: String,
    val logo: String,
    val tvgId: String,
    val headers: Map<String, String>,
    val vod: Boolean
)

class Parsed(val channels: List<Channel>, val epgUrl: String?, val skipped: Int)

class PlaylistMeta(val id: String, var name: String, val url: String, var epgUrl: String, var updated: Long)

/** M3U / M3U8 (IPTV) liste ayrıştırıcı. */
object M3u {
    private val attrRe = Regex("([A-Za-z0-9_-]+)=\"([^\"]*)\"")
    private val vodExt = setOf("mp4", "mkv", "avi", "mov", "wmv", "m4v")

    private fun isVod(url: String, group: String, dur: Double): Boolean {
        if (dur > 0) return true
        val p = url.substringBefore('?').lowercase()
        val last = p.substringAfterLast('/')
        val ext = if (last.contains('.')) last.substringAfterLast('.') else ""
        if (ext in vodExt) return true
        if (p.contains("/movie/") || p.contains("/series/")) return true
        val g = group.lowercase()
        return g.contains("vod") || g.contains("film") || g.contains("movie") ||
            g.contains("dizi") || g.contains("series") || g.contains("sinema")
    }

    fun parse(text: String): Parsed {
        val res = ArrayList<Channel>()
        var epg: String? = null
        var skipped = 0
        var name = ""
        var nameAttr = ""
        var group = ""
        var logo = ""
        var tvgId = ""
        var dur = -1.0
        var hdr = HashMap<String, String>()

        for (raw in text.lineSequence()) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            when {
                l.startsWith("#EXTM3U") -> {
                    val v = Regex("(?:url-tvg|x-tvg-url)=\"([^\"]*)\"").find(l)?.groupValues?.get(1)
                    epg = v?.split(',')?.firstOrNull()?.trim()?.ifEmpty { null }
                }
                l.startsWith("#EXTINF:") -> {
                    val body = l.substring(8)
                    val lastQuote = body.lastIndexOf('"')
                    val comma = body.indexOf(',', if (lastQuote >= 0) lastQuote else 0)
                    val attrs = if (comma >= 0) body.substring(0, comma) else body
                    dur = body.takeWhile { it != ' ' && it != ',' }.toDoubleOrNull() ?: -1.0
                    logo = ""; tvgId = ""; nameAttr = "" // group, #EXTGRP önceden geldiyse korunur
                    attrRe.findAll(attrs).forEach { m ->
                        when (m.groupValues[1].lowercase()) {
                            "group-title" -> if (m.groupValues[2].isNotEmpty()) group = m.groupValues[2]
                            "tvg-logo" -> logo = m.groupValues[2]
                            "tvg-id" -> tvgId = m.groupValues[2]
                            "tvg-name" -> nameAttr = m.groupValues[2]
                        }
                    }
                    name = if (comma >= 0) body.substring(comma + 1).trim() else ""
                    if (name.isEmpty()) name = nameAttr
                }
                l.startsWith("#EXTGRP:") -> if (group.isEmpty()) group = l.substring(8).trim()
                l.startsWith("#EXTVLCOPT:") -> {
                    val kv = l.substring(11)
                    val i = kv.indexOf('=')
                    if (i > 0) {
                        val v = kv.substring(i + 1).trim()
                        when (kv.substring(0, i).trim().lowercase()) {
                            "http-referrer", "http-referer" -> hdr["Referer"] = v
                            "http-user-agent" -> hdr["User-Agent"] = v
                            "http-origin" -> hdr["Origin"] = v
                        }
                    }
                }
                l.startsWith("#") -> {}
                else -> {
                    if (l.startsWith("http://") || l.startsWith("https://")) {
                        res.add(
                            Channel(
                                name.ifEmpty { l.substringBefore('?').substringAfterLast('/') },
                                l, group.ifEmpty { "Diğer" }, logo, tvgId, hdr, isVod(l, group, dur)
                            )
                        )
                    } else {
                        skipped++ // rtmp, udp, rtsp… desteklenmez
                    }
                    name = ""; nameAttr = ""; group = ""; logo = ""; tvgId = ""; dur = -1.0
                    hdr = HashMap()
                }
            }
        }
        return Parsed(res, epg, skipped)
    }
}

/** Playlist'ler, favoriler ve oynatma kuyruğu. */
object IptvStore {
    private fun prefs(c: Context) = c.getSharedPreferences("iptv", Context.MODE_PRIVATE)
    private fun dir(c: Context): File = File(c.filesDir, "iptv").also { it.mkdirs() }
    fun file(c: Context, id: String): File = File(dir(c), "$id.m3u")
    fun epgFile(c: Context, id: String): File = File(dir(c), "$id.epg")

    fun playlists(c: Context): List<PlaylistMeta> {
        val arr = try { JSONArray(prefs(c).getString("list", "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
        val res = ArrayList<PlaylistMeta>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            res.add(PlaylistMeta(o.getString("id"), o.getString("n"), o.getString("u"), o.optString("e", ""), o.optLong("t", 0)))
        }
        return res
    }

    fun save(c: Context, list: List<PlaylistMeta>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("n", it.name).put("u", it.url).put("e", it.epgUrl).put("t", it.updated))
        }
        prefs(c).edit().putString("list", arr.toString()).apply()
    }

    private var cacheId = ""
    private var cache: Parsed? = null

    fun currentId(c: Context): String = prefs(c).getString("current", "") ?: ""
    fun setCurrent(c: Context, id: String) { prefs(c).edit().putString("current", id).apply() }

    /** Listeyi dosyaya yazar ve kaydeder. [url] boşsa dosyadan eklenmiştir. */
    fun add(c: Context, name: String, url: String, text: String): PlaylistMeta {
        val id = System.currentTimeMillis().toString(36)
        file(c, id).writeText(text)
        val epg = M3u.parse(text).epgUrl ?: ""
        val m = PlaylistMeta(id, name, url, epg, System.currentTimeMillis())
        save(c, playlists(c) + m)
        return m
    }

    @Synchronized
    fun update(c: Context, meta: PlaylistMeta, text: String?) {
        if (text != null) {
            file(c, meta.id).writeText(text)
            meta.updated = System.currentTimeMillis()
            if (meta.epgUrl.isEmpty()) meta.epgUrl = M3u.parse(text).epgUrl ?: ""
            if (cacheId == meta.id) { cache = null; cacheId = "" }
        }
        save(c, playlists(c).map { if (it.id == meta.id) meta else it })
    }

    @Synchronized
    fun delete(c: Context, id: String) {
        file(c, id).delete()
        epgFile(c, id).delete()
        save(c, playlists(c).filter { it.id != id })
        if (currentId(c) == id) setCurrent(c, "")
        if (cacheId == id) { cache = null; cacheId = "" }
        Epg.forget(id)
    }

    @Synchronized
    fun load(c: Context, id: String): Parsed {
        val k = cache
        if (k != null && cacheId == id) return k
        val p = M3u.parse(file(c, id).readText())
        cache = p
        cacheId = id
        return p
    }

    fun fetch(url: String): String {
        val client = Http.client(15, 90)
        val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0 (Linux; Android 13)").build()
        return client.newCall(req).execute().use {
            if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
            it.body!!.string()
        }
    }

    // ---- Favoriler ----
    fun favs(c: Context): Set<String> = prefs(c).getStringSet("fav", emptySet()) ?: emptySet()

    fun toggleFav(c: Context, url: String): Boolean {
        val s = HashSet(favs(c))
        val added = if (s.contains(url)) { s.remove(url); false } else { s.add(url); true }
        prefs(c).edit().putStringSet("fav", s).apply()
        return added
    }

    // ---- Oynatma kuyruğu (kanal değiştirme için) ----
    @Volatile var queue: List<Channel> = emptyList()
    @Volatile var queueIndex = 0
}

object Iptv {
    fun typeOf(url: String): String {
        val p = url.substringBefore('?').lowercase()
        return when {
            p.endsWith(".m3u8") || p.contains(".m3u8/") -> "hls"
            p.endsWith(".mpd") -> "dash"
            else -> "direct"
        }
    }

    /** Uzantısız (ör. Xtream) linkler için içeriğe bakarak türü belirler. Arka planda çağır. */
    fun detectType(url: String, headers: Map<String, String>): String {
        val guess = typeOf(url)
        if (guess != "direct") return guess
        return try {
            val f = QualityProbe.sniff(url, headers, 4096)
            when {
                f.isMedia -> "direct"
                f.text?.trimStart()?.startsWith("#EXTM3U") == true -> "hls"
                f.text?.contains("<MPD") == true -> "dash"
                else -> "direct"
            }
        } catch (e: Exception) {
            "direct"
        }
    }

    fun recordIntent(ctx: Context, ch: Channel, type: String, durationMin: Int): Intent =
        Intent(ctx, RecorderService::class.java)
            .putExtra("url", ch.url)
            .putExtra("headers", HashMap(ch.headers))
            .putExtra("type", type)
            .putExtra("title", ch.name)
            .putExtra("duration", durationMin)
}
