package com.example.liverecorder

import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStreamWriter
import java.nio.ByteBuffer
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.Future
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Tek bir HLS medya playlist'ini kaydeder (video, ayrı ses veya altyazı).
 * - Bitmiş (VOD) listelerde parçaları paralel indirir, sırayla yazar.
 * - Canlıda playlist'i yeniler; kopmada 10 dk'ya kadar bekler; yeni parça gelmezse biter.
 * - AES-128 çözer. İsteğe bağlı olarak çıktıyı belirli sürede parçalara böler (altyazıda yok).
 */
class HlsWorker(
    private val net: Net,
    private val playlist: String,
    private val firstText: String,
    private val outBase: File,
    private val kind: String, // "main" | "audio" | "sub"
    private val splitMs: Long,
    private val isRunning: () -> Boolean,
    private val onProgress: () -> Unit
) {
    @Volatile var count = 0
    @Volatile var bytes = 0L
    @Volatile var error: Exception? = null
    val files = ArrayList<File>()
    private val skippedUrls = ConcurrentHashMap.newKeySet<String>()
    val skipped: Int get() = skippedUrls.size

    private class Key(val uri: String, val iv: ByteArray?)
    private class Seg(val url: String, val seq: Long, val key: Key?)

    private val keyCache = ConcurrentHashMap<String, ByteArray>()
    private var fos: FileOutputStream? = null
    private var partNo = 0
    private var partStart = 0L
    private var initBytes: ByteArray? = null
    private var ext = "ts"
    private var subWriter: BufferedWriter? = null
    private val seenCues = HashSet<String>()

    // ---- AES-128 ----
    private fun hex(s: String): ByteArray {
        val h = if (s.length % 2 == 1) "0$s" else s
        val b = ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        return if (b.size >= 16) b.copyOfRange(b.size - 16, b.size) else ByteArray(16 - b.size) + b
    }

    private fun parseKey(line: String): Key? {
        val attrs = line.substringAfter(":")
        val method = Regex("METHOD=([^,]+)").find(attrs)?.groupValues?.get(1) ?: "NONE"
        if (method == "NONE") return null
        if (method != "AES-128") throw IOException("Bu şifreleme türü desteklenmiyor ($method)")
        val uri = Regex("URI=\"([^\"]+)\"").find(attrs)?.groupValues?.get(1)
            ?: throw IOException("Şifre anahtarı adresi yok")
        val iv = Regex("IV=0[xX]([0-9a-fA-F]+)").find(attrs)?.groupValues?.get(1)?.let { hex(it) }
        return Key(net.abs(playlist, uri), iv)
    }

    private fun decrypt(data: ByteArray, key: Key, seq: Long): ByteArray {
        val k = keyCache.getOrPut(key.uri) { net.bytes(key.uri) }
        if (k.size != 16) throw IOException("Şifre anahtarı alınamadı")
        val iv = key.iv ?: ByteBuffer.allocate(16).putLong(8, seq).array()
        val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(k, "AES"), IvParameterSpec(iv))
        return c.doFinal(data)
    }

    private fun <T> retry(block: () -> T): T {
        var last: Exception? = null
        for (attempt in 0 until 3) {
            try {
                return block()
            } catch (e: Exception) {
                last = e
                try { Thread.sleep(1000L * (attempt + 1)) } catch (_: InterruptedException) { break }
            }
        }
        throw IOException(last?.message ?: "indirilemedi")
    }

    private fun fetchSeg(s: Seg): ByteArray = retry {
        val raw = net.bytes(s.url)
        if (s.key != null) decrypt(raw, s.key, s.seq) else raw
    }

    /** Segment listesi. SCTE-35/CUE işaretli reklam bölümleri atlanır (en fazla 10 dk üst üste). */
    private fun parse(text: String): List<Seg> {
        var seq = text.lines().firstOrNull { it.startsWith("#EXT-X-MEDIA-SEQUENCE:") }
            ?.substringAfter(":")?.trim()?.toLongOrNull() ?: 0L
        var key: Key? = null
        var dur = 0.0
        var inAd = false
        var adBudget = 0.0
        var adRun = 0.0
        val skip = Prefs.skipAds && kind == "main"
        val res = ArrayList<Seg>()
        for (l in text.lines()) {
            when {
                l.startsWith("#EXT-X-KEY:") -> { key = parseKey(l); continue }
                l.startsWith("#EXTINF:") -> {
                    dur = l.substringAfter(":").substringBefore(",").toDoubleOrNull() ?: 0.0
                    continue
                }
                l.startsWith("#EXT-X-CUE-OUT-CONT") -> { inAd = true; continue }
                l.startsWith("#EXT-X-CUE-OUT") -> {
                    inAd = true
                    adBudget = Regex("([0-9]+(?:\\.[0-9]+)?)").find(l.substringAfter(":", ""))
                        ?.value?.toDoubleOrNull() ?: 0.0
                    continue
                }
                l.startsWith("#EXT-X-CUE-IN") -> { inAd = false; adBudget = 0.0; continue }
                l.startsWith("#EXT-X-DATERANGE") && (l.contains("stitched-ad") || l.contains("SCTE35-OUT")) -> {
                    val d = Regex("DURATION=([0-9.]+)").find(l)?.groupValues?.get(1)?.toDoubleOrNull() ?: 30.0
                    adBudget = maxOf(adBudget, d)
                    continue
                }
                l.isBlank() || l.startsWith("#") -> continue
            }
            val url = net.abs(playlist, l.trim())
            var adSeg = skip && (inAd || adBudget > 0)
            if (adSeg) {
                adRun += dur
                if (adRun > 600) { inAd = false; adBudget = 0.0; adSeg = false }
            }
            if (adSeg) {
                if (adBudget > 0) adBudget -= dur
                skippedUrls.add(url)
            } else {
                adRun = 0.0
                res.add(Seg(url, seq, key))
            }
            seq++
            dur = 0.0
        }
        return res
    }

    // ---- Yazma ----
    private fun openNext() {
        try { fos?.close() } catch (_: IOException) {}
        partNo++
        val name = if (partNo == 1) "${outBase.name}.$ext" else "${outBase.name}_p$partNo.$ext"
        val f = File(outBase.parentFile, name)
        files.add(f)
        val o = FileOutputStream(f)
        fos = o
        partStart = System.currentTimeMillis()
        initBytes?.let { o.write(it) }
    }

    private fun appendSub(data: ByteArray) {
        val w = subWriter ?: run {
            val f = File(outBase.parentFile, outBase.name + ".vtt")
            files.add(f)
            val nw = BufferedWriter(OutputStreamWriter(FileOutputStream(f), Charsets.UTF_8))
            nw.write("WEBVTT\n\n")
            subWriter = nw
            nw
        }
        val blocks = String(data, Charsets.UTF_8).replace("\r\n", "\n").split("\n\n")
        for (b in blocks) {
            val t = b.trim()
            if (t.isEmpty() || t.startsWith("WEBVTT") || t.startsWith("X-TIMESTAMP-MAP")) continue
            if (seenCues.add(t)) w.write(t + "\n\n")
        }
        count++
        onProgress()
    }

    private fun write(data: ByteArray) {
        if (kind == "sub") { appendSub(data); return }
        val now = System.currentTimeMillis()
        if (fos == null || (splitMs > 0 && now - partStart >= splitMs)) openNext()
        fos!!.write(data)
        bytes += data.size
        count++
        onProgress()
    }

    private fun close() {
        try { fos?.close() } catch (_: IOException) {}
        try { subWriter?.close() } catch (_: IOException) {}
    }

    // ---- Çalıştır ----
    fun run() {
        try {
            if (kind == "sub") {
                ext = "vtt"
            } else {
                val init = Regex("#EXT-X-MAP:.*URI=\"([^\"]+)\"").find(firstText)?.groupValues?.get(1)
                if (init != null) {
                    val u = net.abs(playlist, init)
                    initBytes = retry { net.bytes(u) }
                    ext = "mp4"
                }
            }
            val first = parse(firstText) // desteklenmeyen şifrelemeyi erken yakalar
            if (firstText.contains("#EXT-X-ENDLIST")) vod(first) else live()
        } catch (e: Exception) {
            error = e
        } finally {
            close()
        }
    }

    /** Bitmiş yayın: 6 parça paralel indir, sırayla yaz. */
    private fun vod(segs: List<Seg>) {
        val pool = Executors.newFixedThreadPool(6)
        try {
            val futures = arrayOfNulls<Future<ByteArray?>>(segs.size)
            var submitted = 0
            for (i in segs.indices) {
                if (!isRunning()) break
                while (submitted < segs.size && submitted < i + 8) {
                    val s = segs[submitted]
                    futures[submitted] = pool.submit(Callable<ByteArray?> {
                        try { fetchSeg(s) } catch (e: Exception) { null }
                    })
                    submitted++
                }
                val data = futures[i]!!.get()
                futures[i] = null
                if (data != null) write(data)
            }
        } finally {
            pool.shutdownNow()
        }
    }

    private fun live() {
        var text = firstText
        val seen = HashSet<String>()
        var outageSince = 0L
        var lastNewAt = System.currentTimeMillis()
        val outageLimit = 10 * 60_000L

        while (isRunning()) {
            var added = 0
            for (s in parse(text)) {
                if (!isRunning()) break
                if (!seen.add(s.url)) continue
                val d = try { fetchSeg(s) } catch (e: IOException) { null }
                if (d != null) { write(d); added++ }
            }
            val now = System.currentTimeMillis()
            if (added > 0) lastNewAt = now
            if (text.contains("#EXT-X-ENDLIST")) break

            val target = text.lines().firstOrNull { it.startsWith("#EXT-X-TARGETDURATION:") }
                ?.substringAfter(":")?.trim()?.toIntOrNull() ?: 6
            if (outageSince == 0L && now - lastNewAt > maxOf(60_000L, target * 6000L)) break
            try { Thread.sleep(target * 500L) } catch (_: InterruptedException) { break }

            try {
                text = net.text(playlist)
                if (outageSince != 0L) {
                    outageSince = 0L
                    lastNewAt = System.currentTimeMillis()
                }
            } catch (e: IOException) {
                val t = System.currentTimeMillis()
                if (outageSince == 0L) outageSince = t
                if (t - outageSince > outageLimit) break
            }
        }
    }
}
