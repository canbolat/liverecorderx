package com.example.liverecorder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

data class Watch(
    val id: Int,
    val url: String,
    val headers: Map<String, String>,
    val bandwidth: Long,
    val type: String,
    val audioOnly: Boolean,
    val intervalMin: Int,
    val title: String = ""
)

/** Bir yayın linkini düzenli aralıkla kontrol eder; yayın açılınca kaydı başlatır (tek seferlik). */
object Watcher {
    private fun prefs(c: Context) = c.getSharedPreferences("watch", Context.MODE_PRIVATE)

    fun all(c: Context): List<Watch> {
        val arr = try { JSONArray(prefs(c).getString("list", "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
        val res = ArrayList<Watch>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val hj = o.getJSONObject("h")
            val h = HashMap<String, String>()
            hj.keys().forEach { k -> h[k] = hj.getString(k) }
            res.add(Watch(o.getInt("id"), o.getString("u"), h, o.getLong("b"), o.getString("ty"),
                o.getBoolean("ao"), o.getInt("m"), o.optString("tt", "")))
        }
        return res
    }

    private fun write(c: Context, list: List<Watch>) {
        val arr = JSONArray()
        list.forEach { w ->
            arr.put(
                JSONObject().put("id", w.id).put("u", w.url).put("h", JSONObject(w.headers))
                    .put("b", w.bandwidth).put("ty", w.type).put("ao", w.audioOnly).put("m", w.intervalMin).put("tt", w.title)
            )
        }
        prefs(c).edit().putString("list", arr.toString()).apply()
    }

    fun get(c: Context, id: Int): Watch? = all(c).firstOrNull { it.id == id }

    fun arm(c: Context, w: Watch, whenMs: Long) {
        val i = Intent(c, WatchReceiver::class.java).putExtra("watch_id", w.id)
        val pi = PendingIntent.getBroadcast(c, w.id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val am = c.getSystemService(AlarmManager::class.java)
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi) // tam zamanlı alarm izni yoksa
        }
    }

    fun add(c: Context, w: Watch) {
        write(c, all(c) + w)
        arm(c, w, System.currentTimeMillis() + 60_000L)
    }

    fun remove(c: Context, id: Int) {
        write(c, all(c).filter { it.id != id })
    }

    fun cancel(c: Context, id: Int) {
        val pi = PendingIntent.getBroadcast(
            c, id, Intent(c, WatchReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE
        )
        if (pi != null) {
            c.getSystemService(AlarmManager::class.java).cancel(pi)
            pi.cancel()
        }
        remove(c, id)
    }

    fun rearmAll(c: Context) {
        val now = System.currentTimeMillis()
        all(c).forEach { arm(c, it, now + 60_000L) }
    }
}
