package com.example.liverecorder

import java.io.File

interface Recorder {
    /** Ana dosyayı (ilk parça) döndürür. */
    fun run(): File
    fun stop()
    /** Ek dosyalar: diğer parçalar, altyazılar, birleştirilemeyen ses. */
    val extras: List<File> get() = emptyList()
}
