package com.example.liverecorder

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.media.MediaMetadataRetriever
import java.io.File

class RecordingsActivity : LockedActivity() {

    private class Item(val uri: Uri, val name: String, val size: Long, val added: Long)

    private val items = ArrayList<Item>()
    private val labels = ArrayList<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeUtil.apply(this)
        super.onCreate(savedInstanceState)
        val lv = ListView(this)
        lv.fitsSystemWindows = true
        setContentView(lv)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        lv.adapter = adapter

        lv.setOnItemClickListener { _, _, pos, _ ->
            if (pos < items.size) {
                val it = items[pos]
                val n = it.name.lowercase()
                if (n.endsWith(".vtt") || n.endsWith(".srt") || n.endsWith(".ttml") || n.endsWith(".json")) {
                    startActivity(Intent.createChooser(
                        Intent(Intent.ACTION_VIEW).setDataAndType(it.uri, "text/plain")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Altyazıyı aç"))
                } else {
                    startActivity(Intent(this, PlayerActivity::class.java).setData(it.uri))
                }
            }
        }
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos < items.size) menu(items[pos])
            true
        }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun menu(item: Item) {
        val opts = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        opts.add("Paylaş"); acts.add { share(item) }
        opts.add("Yeniden adlandır"); acts.add { rename(item) }
        if (item.name.endsWith(".ts", true)) {
            opts.add("MP4'e çevir"); acts.add { convert(item) }
        }
        val lower = item.name.lowercase()
        if (lower.endsWith(".mp4") || lower.endsWith(".m4a") || lower.endsWith(".ts")) {
            opts.add("Kırp"); acts.add { trim(item) }
        }
        if (lower.endsWith(".mp4") || lower.endsWith(".ts")) {
            opts.add("Sıkıştır (küçült)"); acts.add { compress(item) }
        }
        opts.add("Sil"); acts.add { confirmDelete(item) }
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(opts.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }

    private fun share(item: Item) {
        val i = Intent(Intent.ACTION_SEND)
            .setType(contentResolver.getType(item.uri) ?: "video/*")
            .putExtra(Intent.EXTRA_STREAM, item.uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Paylaş"))
    }

    private fun rename(item: Item) {
        val et = EditText(this)
        et.setText(item.name.substringBeforeLast('.'))
        AlertDialog.Builder(this)
            .setTitle("Yeniden adlandır")
            .setView(et)
            .setPositiveButton("Kaydet") { _, _ ->
                val n = et.text.toString().trim().replace(Regex("[/\\\\:*?\"<>|]"), "_")
                if (n.isNotEmpty()) {
                    val ext = item.name.substringAfterLast('.', "mp4")
                    try {
                        val cv = ContentValues().apply {
                            put(MediaStore.Video.Media.DISPLAY_NAME, "$n.$ext")
                        }
                        contentResolver.update(item.uri, cv, null, null)
                    } catch (e: Exception) {
                        toast("Adlandırılamadı: ${e.message}")
                    }
                    load()
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun confirmDelete(item: Item) {
        AlertDialog.Builder(this)
            .setTitle("Sil?")
            .setMessage(item.name)
            .setPositiveButton("Sil") { _, _ ->
                try {
                    contentResolver.delete(item.uri, null, null)
                } catch (e: Exception) {
                    toast("Silinemedi: ${e.message}")
                }
                load()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun convert(item: Item) {
        toast("MP4'e çevriliyor, bekle…")
        Thread {
            try {
                val tmp = File(cacheDir, item.name)
                contentResolver.openInputStream(item.uri)!!.use { i -> tmp.outputStream().use { i.copyTo(it) } }
                val mp4 = File(cacheDir, item.name.substringBeforeLast('.') + ".mp4")
                Remuxer.toMp4(tmp, mp4)
                tmp.delete()
                MediaSaver.save(this, mp4) // kopyalar ve cache dosyasını siler
                contentResolver.delete(item.uri, null, null)
                runOnUiThread { toast("MP4 hazır"); load() }
            } catch (e: Exception) {
                runOnUiThread { toast("Çevrilemedi: ${e.message}") }
            }
        }.start()
    }

    // ---- Kırp ----
    private fun fmtTime(us: Long): String {
        val s = us / 1_000_000
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
        else "%d:%02d".format(s / 60, s % 60)
    }

    private fun parseTime(t: String): Long? = try {
        var sec = 0.0
        for (p in t.trim().split(":")) sec = sec * 60 + p.toDouble()
        (sec * 1_000_000).toLong()
    } catch (e: Exception) {
        null
    }

    private fun durationUs(uri: Uri): Long = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(this, uri)
        val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release()
        d * 1000
    } catch (e: Exception) {
        0L
    }

    private fun trim(item: Item) {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad, pad, 0)
        val a = EditText(this)
        a.hint = "Başlangıç (dk:sn)"
        a.setText("0:00")
        val b = EditText(this)
        b.hint = "Bitiş (dk:sn)"
        b.setText(fmtTime(durationUs(item.uri)))
        box.addView(a)
        box.addView(b)
        AlertDialog.Builder(this)
            .setTitle("Kırp (yeniden kodlama yok, başlangıç anahtar kareye yuvarlanır)")
            .setView(box)
            .setPositiveButton("Kırp") { _, _ ->
                val s = parseTime(a.text.toString())
                val e = parseTime(b.text.toString())
                if (s == null || e == null || e <= s) toast("Zaman geçersiz") else runTrim(item, s, e)
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun runTrim(item: Item, s: Long, e: Long) {
        toast("Kırpılıyor…")
        Thread {
            try {
                val ext = if (item.name.endsWith(".m4a", true)) "m4a" else "mp4"
                val out = File(cacheDir, item.name.substringBeforeLast('.') + "_kirpildi." + ext)
                out.delete()
                Remuxer.trim(this, item.uri, out, s, e)
                MediaSaver.save(this, out)
                runOnUiThread { toast("Kırpılmış kopya kaydedildi"); load() }
            } catch (ex: Exception) {
                AppLog.e("Kırpma", ex)
                runOnUiThread { toast("Kırpılamadı: ${ex.message}") }
            }
        }.start()
    }

    // ---- Sıkıştır ----
    private fun compress(item: Item) {
        val h = try {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, item.uri)
            val v = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            r.release()
            v
        } catch (e: Exception) {
            0
        }
        if (h == 0) { toast("Bu dosyada video yok"); return }
        val opts = listOf(720 to 2_000_000, 480 to 1_000_000, 360 to 600_000).filter { it.first < h }
        if (opts.isEmpty()) { toast("Video zaten küçük (${h}p)"); return }
        AlertDialog.Builder(this)
            .setTitle("Hedef çözünürlük (kaynak ${h}p)")
            .setItems(opts.map { "${it.first}p" }.toTypedArray()) { _, i ->
                runCompress(item, opts[i].first, opts[i].second)
            }
            .show()
    }

    private fun runCompress(item: Item, height: Int, bitrate: Int) {
        val out = File(cacheDir, item.name.substringBeforeLast('.') + "_${height}p.mp4")
        out.delete()
        val c = Compressor(this)
        val msg = TextView(this)
        val pad = (20 * resources.displayMetrics.density).toInt()
        msg.setPadding(pad, pad, pad, 0)
        msg.text = "Başlıyor…"
        val dlg = AlertDialog.Builder(this)
            .setTitle("Sıkıştırılıyor")
            .setView(msg)
            .setCancelable(false)
            .setNegativeButton("İptal") { _, _ -> c.cancel(); out.delete() }
            .create()
        dlg.show()
        try {
            c.start(item.uri, out, height, bitrate, { p -> msg.text = "%$p" }) { err ->
                dlg.dismiss()
                if (err != null) {
                    AppLog.e("Sıkıştırma", err)
                    toast("Sıkıştırılamadı: ${err.message}")
                    out.delete()
                } else {
                    val before = item.size
                    val after = out.length()
                    Thread {
                        try {
                            MediaSaver.save(this, out)
                            runOnUiThread { toast("Hazır: ${before / 1_000_000} MB → ${after / 1_000_000} MB"); load() }
                        } catch (ex: Exception) {
                            AppLog.e("Sıkıştırma kaydı", ex)
                            runOnUiThread { toast("Kaydedilemedi: ${ex.message}") }
                        }
                    }.start()
                }
            }
        } catch (ex: Exception) {
            dlg.dismiss()
            AppLog.e("Sıkıştırma", ex)
            toast("Başlatılamadı: ${ex.message}")
        }
    }

    private fun query(col: Uri, rel: String) {
        val proj = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED
        )
        contentResolver.query(
            col, proj, "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("$rel/%"), null
        )?.use { c ->
            while (c.moveToNext()) {
                items.add(
                    Item(ContentUris.withAppendedId(col, c.getLong(0)), c.getString(1), c.getLong(2), c.getLong(3))
                )
            }
        }
    }

    private fun load() {
        items.clear()
        labels.clear()
        query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "Movies/LiveRecorder")
        query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "Music/LiveRecorder")
        query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, "Download/LiveRecorder")
        items.sortByDescending { it.added }
        items.forEach { labels.add("${it.name}\n${it.size / 1_000_000} MB") }
        if (items.isEmpty()) labels.add("Henüz kayıt yok")
        adapter.notifyDataSetChanged()
    }
}
