package com.example.liverecorder

import android.app.Activity
import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SchedulesActivity : LockedActivity() {

    private class Row(val label: String, val cancel: () -> Unit)

    private var rows: List<Row> = emptyList()
    private val labels = ArrayList<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeUtil.apply(this)
        super.onCreate(savedInstanceState)
        val lv = ListView(this)
        lv.fitsSystemWindows = true
        setContentView(lv)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        lv.adapter = adapter

        lv.setOnItemClickListener { _, _, pos, _ ->
            if (pos >= rows.size) return@setOnItemClickListener
            val r = rows[pos]
            AlertDialog.Builder(this)
                .setTitle("İptal et?")
                .setMessage(r.label)
                .setPositiveButton("İptal et") { _, _ -> r.cancel(); load() }
                .setNegativeButton("Vazgeç", null)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun short(u: String): String {
        val p = Uri.parse(u)
        return "${p.host}/…/${p.lastPathSegment}"
    }

    private fun load() {
        val now = System.currentTimeMillis()
        val fmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        val list = ArrayList<Row>()
        Scheduler.all(this).filter { it.whenMs > now }.forEach { s ->
            val dur = if (s.durMin > 0) "${s.durMin} dk" else "sınırsız"
            list.add(Row("⏰ ${fmt.format(Date(s.whenMs))} • $dur\n${short(s.url)}") { Scheduler.cancel(this, s.id) })
        }
        Watcher.all(this).forEach { w ->
            list.add(Row("👁 İzleniyor • ${w.intervalMin} dk'da bir\n${short(w.url)}") { Watcher.cancel(this, w.id) })
        }
        rows = list
        labels.clear()
        rows.forEach { labels.add(it.label) }
        if (rows.isEmpty()) labels.add("Zamanlanmış veya izlenen kayıt yok")
        adapter.notifyDataSetChanged()
    }
}
