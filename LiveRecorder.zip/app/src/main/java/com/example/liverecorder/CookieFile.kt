package com.example.liverecorder

import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import java.io.File

/** WebView'deki oturum çerezlerini yt-dlp'nin okuyacağı Netscape biçiminde geçici dosyaya yazar. */
object CookieFile {
    fun write(ctx: Context, pageUrl: String): String? {
        val raw = CookieManager.getInstance().getCookie(pageUrl) ?: return null
        val host = Uri.parse(pageUrl).host ?: return null
        val parts = host.split('.')
        val domain = "." + (if (parts.size >= 2) parts.takeLast(2).joinToString(".") else host)
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        raw.split(';').forEach { kv ->
            val i = kv.indexOf('=')
            if (i <= 0) return@forEach
            val name = kv.substring(0, i).trim()
            val value = kv.substring(i + 1).trim()
            sb.append("$domain\tTRUE\t/\tTRUE\t2147483647\t$name\t$value\n")
        }
        val f = File(ctx.cacheDir, "cookies.txt")
        f.writeText(sb.toString())
        return f.absolutePath
    }
}
