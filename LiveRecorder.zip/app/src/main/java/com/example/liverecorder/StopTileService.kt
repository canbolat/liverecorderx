package com.example.liverecorder

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Bildirim panelinden tek dokunuşla tüm kayıtları durdurur. */
class StopTileService : TileService() {

    override fun onStartListening() {
        refresh()
    }

    override fun onClick() {
        startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        val n = RecorderService.activeCount
        t.state = if (n > 0) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = if (n > 0) "Kayıtları durdur ($n)" else "Kayıt yok"
        t.updateTile()
    }
}
