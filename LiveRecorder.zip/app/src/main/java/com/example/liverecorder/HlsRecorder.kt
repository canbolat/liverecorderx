package com.example.liverecorder

import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * HLS kaydedici: master playlist'ten video, (ayrıysa) ses ve altyazı akışlarını seçer,
 * her biri için bir HlsWorker çalıştırır, sonunda video+sesi MP4'te birleştirir.
 */
class HlsRecorder(
    private val url: String,
    private val headers: Map<String, String>,
    private val dir: File,
    private val bandwidth: Long,
    private val audioOnly: Boolean,
    private val onStatus: (String) -> Unit
) : Recorder {

    @Volatile private var running = true
    override fun stop() { running = false }

    private val net = Net(headers)
    private val extraFiles = ArrayList<File>()
    override val extras: List<File> get() = extraFiles

    private class Variant(val uri: String, val bw: Long, val attrs: Map<String, String>)

    private fun attrs(line: String): Map<String, String> {
        val m = HashMap<String, String>()
        Regex("([A-Z0-9-]+)=(\"[^\"]*\"|[^,]*)").findAll(line.substringAfter(":")).forEach {
            m[it.groupValues[1]] = it.groupValues[2].trim('"')
        }
        return m
    }

    private fun variants(base: String, master: String): List<Variant> {
        val lines = master.lines()
        val res = ArrayList<Variant>()
        for (i in lines.indices) {
            if (!lines[i].startsWith("#EXT-X-STREAM-INF")) continue
            val a = attrs(lines[i])
            val uri = lines.drop(i + 1).firstOrNull { it.isNotBlank() && !it.startsWith("#") } ?: continue
            res.add(Variant(net.abs(base, uri.trim()), a["BANDWIDTH"]?.toLongOrNull() ?: 0L, a))
        }
        return res
    }

    private fun renditions(master: String, type: String, group: String?): List<Map<String, String>> =
        master.lines().filter { it.startsWith("#EXT-X-MEDIA:") }.map { attrs(it) }
            .filter { it["TYPE"] == type && (group == null || it["GROUP-ID"] == group) && !it["URI"].isNullOrEmpty() }

    private fun prefs(csv: String) = csv.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    private fun pickByLang(list: List<Map<String, String>>, csv: String): Map<String, String>? {
        for (code in prefs(csv)) {
            val hit = list.firstOrNull { (it["LANGUAGE"] ?: "").lowercase().startsWith(code) }
            if (hit != null) return hit
        }
        return null
    }

    private fun pickVariant(vs: List<Variant>): Variant =
        vs.maxByOrNull { v -> if (bandwidth > 0) -Math.abs(v.bw - bandwidth) else v.bw }!!

    private var lastReport = 0L

    override fun run(): File {
        var playlist = url
        var audioPl: String? = null
        var subPl: String? = null
        var subLang = "sub"
        var text = net.text(playlist)

        if (text.contains("#EXT-X-STREAM-INF")) {
            val master = text
            val vs = variants(playlist, master)
            if (vs.isEmpty()) throw IOException("Varyant bulunamadı")
            val chosen = if (audioOnly) vs.minByOrNull { it.bw }!! else pickVariant(vs)

            if (audioOnly) {
                val all = renditions(master, "AUDIO", null)
                val a = pickByLang(all, Prefs.audioLang) ?: all.firstOrNull { it["DEFAULT"] == "YES" } ?: all.firstOrNull()
                playlist = if (a != null) net.abs(url, a["URI"]!!) else chosen.uri
            } else {
                playlist = chosen.uri
                val aList = renditions(master, "AUDIO", chosen.attrs["AUDIO"])
                if (aList.isNotEmpty()) {
                    val a = pickByLang(aList, Prefs.audioLang)
                        ?: aList.firstOrNull { it["DEFAULT"] == "YES" } ?: aList.first()
                    audioPl = net.abs(url, a["URI"]!!)
                }
                if (Prefs.saveSubs) {
                    val sList = renditions(master, "SUBTITLES", chosen.attrs["SUBTITLES"])
                    val s = if (prefs(Prefs.subLang).isEmpty()) sList.firstOrNull { it["FORCED"] != "YES" }
                    else pickByLang(sList, Prefs.subLang)
                    if (s != null) {
                        subPl = net.abs(url, s["URI"]!!)
                        subLang = (s["LANGUAGE"] ?: "sub").lowercase()
                    }
                }
            }
            text = net.text(playlist)
        }

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val base = File(dir, if (audioPl != null) "kayit_${stamp}_v" else "kayit_$stamp")
        val splitMs = if (audioPl == null) Prefs.splitMin * 60_000L else 0L

        lateinit var main: HlsWorker
        var audio: HlsWorker? = null
        var sub: HlsWorker? = null

        fun report() {
            val now = System.currentTimeMillis()
            if (now - lastReport < 1500) return
            lastReport = now
            val a = audio
            val s = sub
            onStatus(
                "Kaydediliyor: ${main.count} parça • ${main.bytes / 1_000_000} MB" +
                    (if (a != null) " • ses ${a.count}" else "") +
                    (if (main.skipped > 0) " • reklam atlandı ${main.skipped}" else "") +
                    (if (s != null) " • altyazı ${s.count}" else "")
            )
        }

        main = HlsWorker(net, playlist, text, base, "main", splitMs, { running }) { report() }
        if (audioPl != null) {
            try {
                audio = HlsWorker(net, audioPl, net.text(audioPl), File(dir, "kayit_${stamp}_audio"),
                    "audio", 0L, { running }) { report() }
            } catch (_: Exception) { /* ses alınamazsa yalnızca video */ }
        }
        if (subPl != null) {
            try {
                sub = HlsWorker(net, subPl, net.text(subPl), File(dir, "kayit_$stamp.$subLang"),
                    "sub", 0L, { running }) { report() }
            } catch (_: Exception) { /* altyazı alınamazsa devam */ }
        }

        val threads = ArrayList<Thread>()
        for (w in listOfNotNull(audio, sub)) {
            val t = Thread { w.run() }
            t.start()
            threads.add(t)
        }
        main.run()
        threads.forEach { it.join() }

        main.error?.let { AppLog.e("HLS ana akış", it) }
        audio?.error?.let { AppLog.e("HLS ses akışı", it) }
        sub?.error?.let { AppLog.e("HLS altyazı", it) }
        if (main.skipped > 0) AppLog.add("I", "HLS: ${main.skipped} reklam parçası atlandı")
        if (main.count == 0) {
            main.files.forEach { it.delete() }
            audio?.files?.forEach { it.delete() }
            sub?.files?.forEach { it.delete() }
            throw main.error ?: IOException("Kayıt boş (hiç parça indirilemedi)")
        }

        var result = main.files[0]
        val a = audio
        if (a != null && a.count > 0 && a.files.isNotEmpty()) {
            onStatus("Video ve ses birleştiriliyor…")
            val out = File(dir, "kayit_$stamp.mp4")
            try {
                Remuxer.mux(main.files[0], a.files[0], out)
                main.files.forEach { it.delete() }
                a.files.forEach { it.delete() }
                result = out
            } catch (e: Exception) {
                out.delete()
                extraFiles.addAll(a.files) // birleşmezse ses ayrı kalsın
            }
        } else {
            a?.files?.forEach { it.delete() }
            extraFiles.addAll(main.files.drop(1))
        }
        val s = sub
        if (s != null) {
            if (s.count > 0) extraFiles.addAll(s.files) else s.files.forEach { it.delete() }
        }
        return result
    }
}
