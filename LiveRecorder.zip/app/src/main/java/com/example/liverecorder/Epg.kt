package com.example.liverecorder

import android.content.Context
import android.util.Xml
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.zip.GZIPInputStream

class Prog(val start: Long, val stop: Long, val title: String, val desc: String)

/** XMLTV program rehberi: indirir, yakın zamanı süzer, dosyaya yazar. */
object Epg {
    private val mem = HashMap<String, Map<String, List<Prog>>>()

    fun forget(id: String) { synchronized(mem) { mem.remove(id) } }

    fun load(c: Context, id: String, force: Boolean = false): Map<String, List<Prog>> {
        if (!force) synchronized(mem) { mem[id]?.let { return it } }
        val f = IptvStore.epgFile(c, id)
        val map = HashMap<String, MutableList<Prog>>()
        if (f.exists()) {
            f.forEachLine { line ->
                val p = line.split('\t')
                if (p.size >= 5) {
                    val s = p[1].toLongOrNull()
                    val e = p[2].toLongOrNull()
                    if (s != null && e != null) map.getOrPut(p[0]) { ArrayList() }.add(Prog(s, e, p[3], p[4]))
                }
            }
        }
        synchronized(mem) { mem[id] = map }
        return map
    }

    fun isStale(c: Context, id: String): Boolean {
        val f = IptvStore.epgFile(c, id)
        return !f.exists() || System.currentTimeMillis() - f.lastModified() > 12 * 3_600_000L
    }

    fun now(map: Map<String, List<Prog>>, tvgId: String, t: Long): Prog? {
        if (tvgId.isEmpty()) return null
        return map[tvgId.lowercase()]?.firstOrNull { it.start <= t && t < it.stop }
    }

    fun upcoming(map: Map<String, List<Prog>>, tvgId: String, t: Long, n: Int): List<Prog> {
        if (tvgId.isEmpty()) return emptyList()
        return map[tvgId.lowercase()]?.filter { it.stop > t }?.take(n) ?: emptyList()
    }

    private val f1 = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)
    private val f2 = SimpleDateFormat("yyyyMMddHHmmss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }

    private fun parseTime(s: String?): Long {
        if (s == null) return 0L
        val t = s.trim()
        return try {
            f1.parse(t)?.time ?: 0L
        } catch (e: Exception) {
            try { f2.parse(t.take(14))?.time ?: 0L } catch (e2: Exception) { 0L }
        }
    }

    private fun clean(s: String, max: Int) = s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim().take(max)

    /** EPG'yi indirip ayrıştırır (.gz desteklenir). Büyük dosyalarda birkaç on saniye sürebilir. */
    @Synchronized
    fun refresh(c: Context, id: String, url: String) {
        val client = Http.client(15, 120)
        val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0 (Linux; Android 13)").build()
        val from = System.currentTimeMillis() - 3_600_000L
        val to = System.currentTimeMillis() + 36 * 3_600_000L
        val map = HashMap<String, MutableList<Prog>>()

        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            val bis = BufferedInputStream(resp.body!!.byteStream())
            bis.mark(2)
            val b0 = bis.read()
            val b1 = bis.read()
            bis.reset()
            val stream: InputStream = if (b0 == 0x1f && b1 == 0x8b) GZIPInputStream(bis) else bis

            val parser = Xml.newPullParser()
            parser.setInput(stream, null)
            var ev = parser.eventType
            var inProg = false
            var tag = ""
            var ch = ""
            var st = 0L
            var sp = 0L
            var title = ""
            var desc = ""
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> {
                        tag = parser.name
                        if (tag == "programme") {
                            inProg = true
                            ch = (parser.getAttributeValue(null, "channel") ?: "").lowercase()
                            st = parseTime(parser.getAttributeValue(null, "start"))
                            sp = parseTime(parser.getAttributeValue(null, "stop"))
                            title = ""
                            desc = ""
                        }
                    }
                    XmlPullParser.TEXT -> if (inProg) {
                        if (tag == "title" && title.isEmpty()) title = parser.text
                        else if (tag == "desc" && desc.isEmpty()) desc = parser.text
                    }
                    XmlPullParser.END_TAG -> {
                        if (parser.name == "programme") {
                            inProg = false
                            if (ch.isNotEmpty() && sp > from && st < to) {
                                val l = map.getOrPut(ch) { ArrayList() }
                                if (l.size < 60) l.add(Prog(st, sp, clean(title, 120), clean(desc, 300)))
                            }
                        }
                        tag = ""
                    }
                }
                ev = parser.next()
            }
        }

        val sorted = HashMap<String, List<Prog>>()
        val sb = StringBuilder()
        for ((k, v) in map) {
            val s = v.sortedBy { it.start }
            sorted[k] = s
            s.forEach {
                sb.append(k).append('\t').append(it.start).append('\t').append(it.stop)
                    .append('\t').append(it.title).append('\t').append(it.desc).append('\n')
            }
        }
        IptvStore.epgFile(c, id).writeText(sb.toString())
        synchronized(mem) { mem[id] = sorted }
    }
}
