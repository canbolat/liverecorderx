package com.example.liverecorder

import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import java.io.File
import android.net.Uri
import java.io.IOException

class Saved(val path: String, val uri: Uri)

/**
 * Kaydı galeriye taşır: video -> Movies/LiveRecorder, ses -> Music/LiveRecorder,
 * altyazı -> Download/LiveRecorder. Android 10+ için izin gerekmez.
 */
object MediaSaver {
    private val audioExt = setOf("m4a", "mp3", "aac", "ogg", "opus")
    private val subExt = setOf("vtt", "srt", "ttml", "json")

    fun save(ctx: Context, f: File): String = saveWithUri(ctx, f).path

    fun saveWithUri(ctx: Context, f: File): Saved {
        val ext = f.extension.lowercase()
        if (ext == "bin") throw IOException("Bu biçim galeriye taşınamaz")
        val audio = ext in audioExt
        val sub = ext in subExt
        val mime = when (ext) {
            "m4a" -> "audio/mp4"
            "mp3" -> "audio/mpeg"
            "aac" -> "audio/aac"
            "ogg", "opus" -> "audio/ogg"
            "vtt" -> "text/vtt"
            "srt" -> "application/x-subrip"
            "ttml" -> "application/ttml+xml"
            "json" -> "application/json"
            "ts" -> "video/mp2t"
            "flv" -> "video/x-flv"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            "avi" -> "video/x-msvideo"
            "wmv" -> "video/x-ms-wmv"
            "mov" -> "video/quicktime"
            else -> "video/mp4"
        }
        val collection = when {
            sub -> MediaStore.Downloads.EXTERNAL_CONTENT_URI
            audio -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val rel = when {
            sub -> "Download/LiveRecorder"
            audio -> "Music/LiveRecorder"
            else -> "Movies/LiveRecorder"
        }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val r = ctx.contentResolver
        val uri = r.insert(collection, cv) ?: throw IOException("MediaStore kaydı oluşturulamadı")
        r.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        cv.clear()
        cv.put(MediaStore.MediaColumns.IS_PENDING, 0)
        r.update(uri, cv, null, null)
        f.delete()
        return Saved("$rel/${f.name}", uri)
    }
}
