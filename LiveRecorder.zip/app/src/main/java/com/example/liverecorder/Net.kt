package com.example.liverecorder

import okhttp3.Request
import java.io.IOException
import java.net.URI

/** Başlıkları taşıyan küçük HTTP yardımcısı (HLS işçileri için). */
class Net(private val headers: Map<String, String>) {
    private val client = Http.client(15, 30)
    private val ua = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"

    private fun req(u: String) = Request.Builder().url(u)
        .header("User-Agent", ua)
        .apply { headers.forEach { (k, v) -> header(k, v) } }
        .build()

    fun text(u: String): String =
        client.newCall(req(u)).execute().use {
            if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
            it.body!!.string()
        }

    fun bytes(u: String): ByteArray =
        client.newCall(req(u)).execute().use {
            if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
            it.body!!.bytes()
        }

    fun abs(base: String, ref: String): String = URI(base).resolve(ref).toString()
}
