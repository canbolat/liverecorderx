package com.example.liverecorder

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Sosyal medya / video sayfası indirici (yt-dlp, youtubedl-android kütüphanesi üzerinden).
 * Sayfa adresini verirsin; yt-dlp videoyu bulur, indirir, ses+videoyu birleştirir.
 */
class SocialRecorder(
    private val ctx: Context,
    private val url: String,
    private val dir: File,
    private val audioOnly: Boolean,
    private val maxHeight: Int,
    private val cookiesPath: String?,
    private val onStatus: (String) -> Unit
) : Recorder {

    companion object {
        @Volatile private var ready = false

        @Synchronized
        fun ensureInit(c: Context) {
            if (ready) return
            YoutubeDL.init(c.applicationContext)
            FFmpeg.init(c.applicationContext)
            ready = true
        }
    }

    @Volatile private var running = true
    private val processId = "rec_" + System.nanoTime()
    private val extraFiles = ArrayList<File>()
    override val extras: List<File> get() = extraFiles

    override fun stop() {
        running = false
        try { YoutubeDL.destroyProcessById(processId) } catch (_: Exception) {}
    }

    private fun shorten(msg: String?): String {
        val m = msg ?: "bilinmeyen hata"
        val line = m.lines().lastOrNull { it.contains("ERROR") } ?: m.lines().lastOrNull { it.isNotBlank() } ?: m
        return line.trim().take(220)
    }

    override fun run(): File {
        onStatus("Hazırlanıyor (ilk kullanımda birkaç saniye sürebilir)…")
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val prefix = "kayit_$stamp"
        try {
            ensureInit(ctx)
            val req = YoutubeDLRequest(url)
            req.addOption("-o", File(dir, "${prefix}_%(autonumber)02d.%(ext)s").absolutePath)
            req.addOption("--playlist-end", 10)
            req.addOption("--no-mtime")
            if (audioOnly) {
                req.addOption("-x")
                req.addOption("--audio-format", "m4a")
            } else {
                val h = if (maxHeight > 0) "[height<=$maxHeight]" else ""
                req.addOption("-f", "bv*$h[ext=mp4]+ba[ext=m4a]/b$h[ext=mp4]/bv*$h+ba/b$h/b")
                req.addOption("--merge-output-format", "mp4")
            }
            val proxy = Prefs.proxy.trim()
            if (proxy.isNotEmpty()) req.addOption("--proxy", proxy)
            cookiesPath?.let { req.addOption("--cookies", it) }

            YoutubeDL.execute(req, processId) { progress, eta, _ ->
                onStatus("İndiriliyor: %${progress.toInt()}" + if (eta > 0) " • ${eta} sn kaldı" else "")
            }
        } catch (e: Exception) {
            AppLog.e("Sosyal medya indirme", e)
            cleanup(prefix, keepMedia = false)
            if (!running) throw IOException("Durduruldu")
            throw IOException(shorten(e.message))
        } finally {
            cookiesPath?.let { try { File(it).delete() } catch (_: Exception) {} }
        }

        val okExt = setOf("mp4", "m4a", "mp3", "webm", "mkv", "mov", "ogg", "opus", "aac")
        val files = (dir.listFiles() ?: emptyArray()).filter { it.name.startsWith(prefix) }
        files.filter { it.extension.lowercase() !in okExt }.forEach { it.delete() } // .part, fotoğraf vb.
        val media = files.filter { it.extension.lowercase() in okExt }.sortedBy { it.name }
        if (media.isEmpty()) throw IOException("Video bulunamadı (gönderi yalnızca fotoğraf olabilir)")
        extraFiles.addAll(media.drop(1))
        return media[0]
    }

    private fun cleanup(prefix: String, keepMedia: Boolean) {
        (dir.listFiles() ?: emptyArray()).filter { it.name.startsWith(prefix) }.forEach {
            if (!keepMedia || it.extension.lowercase() in setOf("part", "ytdl", "temp")) it.delete()
        }
    }
}
