package com.example.liverecorder

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Basit dosya günlüğü: hataları uygulama içinde göstermek ve paylaşmak için. */
object AppLog {
    private var file: File? = null

    fun init(c: Context) { file = File(c.filesDir, "app.log") }

    @Synchronized
    fun add(level: String, msg: String) {
        val f = file ?: return
        try {
            if (f.length() > 200_000) f.writeText(f.readText().takeLast(100_000))
            val ts = SimpleDateFormat("dd.MM HH:mm:ss", Locale.US).format(Date())
            f.appendText("$ts $level $msg\n")
        } catch (_: Exception) {
        }
    }

    fun e(tag: String, t: Throwable) {
        val trace = t.stackTrace.take(8).joinToString("\n") { "    at $it" }
        add("E", "$tag: ${t.javaClass.simpleName}: ${t.message}\n$trace")
    }

    @Synchronized
    fun read(): String = try { file?.readText() ?: "" } catch (e: Exception) { "" }

    @Synchronized
    fun clear() { try { file?.writeText("") } catch (_: Exception) {} }
}
