package com.example.liverecorder

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONArray
import org.json.JSONObject

/** Uygulama ayarları (SharedPreferences). LiveApp.onCreate içinde init edilir. */
object Prefs {
    lateinit var p: SharedPreferences
    fun init(c: Context) { p = c.getSharedPreferences("settings", Context.MODE_PRIVATE) }

    private fun bool(k: String, d: Boolean) = p.getBoolean(k, d)
    private fun int(k: String, d: Int) = p.getInt(k, d)
    private fun str(k: String, d: String) = p.getString(k, d) ?: d
    private fun putB(k: String, v: Boolean) { p.edit().putBoolean(k, v).apply() }
    private fun putI(k: String, v: Int) { p.edit().putInt(k, v).apply() }
    private fun putS(k: String, v: String) { p.edit().putString(k, v).apply() }

    var dark: Boolean get() = bool("dark", false); set(v) = putB("dark", v)
    var wifiOnly: Boolean get() = bool("wifiOnly", false); set(v) = putB("wifiOnly", v)
    var maxConcurrent: Int get() = int("maxConcurrent", 2); set(v) = putI("maxConcurrent", v)
    var splitMin: Int get() = int("splitMin", 0); set(v) = putI("splitMin", v)
    var minFreeMb: Int get() = int("minFreeMb", 500); set(v) = putI("minFreeMb", v)
    var saveSubs: Boolean get() = bool("saveSubs", true); set(v) = putB("saveSubs", v)
    var subLang: String get() = str("subLang", "tr,en"); set(v) = putS("subLang", v)
    var audioLang: String get() = str("audioLang", ""); set(v) = putS("audioLang", v)
    var adBlock: Boolean get() = bool("adBlock", true); set(v) = putB("adBlock", v)
    var adHosts: String get() = str("adHosts", ""); set(v) = putS("adHosts", v)
    var proxy: String get() = str("proxy", ""); set(v) = putS("proxy", v)
    var dns: Int get() = int("dns", 0); set(v) = putI("dns", v)
    var watchMin: Int get() = int("watchMin", 5); set(v) = putI("watchMin", v)
    var quickShare: Boolean get() = bool("quickShare", true); set(v) = putB("quickShare", v)
    var socialHeight: Int get() = int("socialHeight", 0); set(v) = putI("socialHeight", v)
    var lockMode: Int get() = int("lockMode", 0); set(v) = putI("lockMode", v)
    var pinHash: String get() = str("pinHash", ""); set(v) = putS("pinHash", v)
    var pinSalt: String get() = str("pinSalt", ""); set(v) = putS("pinSalt", v)

    private fun hashPin(salt: String, pin: String): String =
        java.security.MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun setPin(pin: String) {
        val r = java.security.SecureRandom()
        val salt = (1..16).joinToString("") { "%02x".format(r.nextInt(256)) }
        pinSalt = salt
        pinHash = hashPin(salt, pin)
    }

    fun checkPin(pin: String): Boolean = pinHash.isEmpty() || hashPin(pinSalt, pin) == pinHash

    var clipWatch: Boolean get() = bool("clipWatch", true); set(v) = putB("clipWatch", v)
    var skipAds: Boolean get() = bool("skipAds", true); set(v) = putB("skipAds", v)
    var autoDeleteDays: Int get() = int("autoDeleteDays", 0); set(v) = putI("autoDeleteDays", v)
    var maxTotalGb: Int get() = int("maxTotalGb", 0); set(v) = putI("maxTotalGb", v)

    fun onWifi(c: Context): Boolean {
        val cm = c.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }
}

class LibItem(val title: String, val url: String)

/** Yer imleri ve geçmiş. */
object Library {
    private fun load(k: String): MutableList<LibItem> {
        val arr = try { JSONArray(Prefs.p.getString("lib_$k", "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
        val res = ArrayList<LibItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            res.add(LibItem(o.getString("t"), o.getString("u")))
        }
        return res
    }

    private fun save(k: String, l: List<LibItem>) {
        val arr = JSONArray()
        l.forEach { arr.put(JSONObject().put("t", it.title).put("u", it.url)) }
        Prefs.p.edit().putString("lib_$k", arr.toString()).apply()
    }

    fun list(k: String): List<LibItem> = load(k)

    fun addBookmark(t: String, u: String) {
        val l = load("bookmarks")
        if (l.none { it.url == u }) { l.add(0, LibItem(t, u)); save("bookmarks", l) }
    }

    fun addHistory(t: String, u: String) {
        if (!u.startsWith("http")) return
        val l = load("history")
        l.removeAll { it.url == u }
        l.add(0, LibItem(t, u))
        save("history", l.take(200))
    }

    fun remove(k: String, index: Int) {
        val l = load(k)
        if (index in l.indices) { l.removeAt(index); save(k, l) }
    }

    fun clear(k: String) { save(k, emptyList()) }
}

/** Basit alan adı tabanlı reklam engelleyici (WebView istekleri için). */
object AdBlock {
    private val defaults = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "adnxs.com", "taboola.com", "outbrain.com", "popads.net", "propellerads.com", "exoclick.com",
        "adsterra.com", "juicyads.com", "trafficjunky.com", "pubmatic.com", "rubiconproject.com",
        "criteo.com", "scorecardresearch.com", "moatads.com", "amazon-adsystem.com", "adform.net",
        "smartadserver.com"
    )
    private var cacheKey = "\u0000"
    private var cache: List<String> = defaults

    private fun hosts(): List<String> {
        val raw = Prefs.adHosts
        if (raw != cacheKey) {
            cacheKey = raw
            cache = defaults + raw.split(',', '\n', ' ').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        }
        return cache
    }

    fun isAd(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return hosts().any { h == it || h.endsWith(".$it") }
    }
}

object ThemeUtil {
    fun apply(a: Activity) {
        a.setTheme(
            if (Prefs.dark) android.R.style.Theme_Material_NoActionBar
            else android.R.style.Theme_Material_Light_NoActionBar
        )
    }
}
