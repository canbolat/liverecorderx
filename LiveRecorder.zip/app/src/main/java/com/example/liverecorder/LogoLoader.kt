package com.example.liverecorder

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.widget.ImageView
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** Kanal logoları için küçük, bağımlılıksız asenkron yükleyici (bellek önbellekli). */
object LogoLoader {
    private val cache = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(3)
    private val failed = ConcurrentHashMap.newKeySet<String>()
    private val client by lazy { Http.client(8, 10) }

    fun load(url: String, view: ImageView) {
        view.tag = url
        val hit = if (url.isEmpty()) null else cache.get(url)
        if (hit != null) { view.setImageBitmap(hit); return }
        view.setImageDrawable(null)
        if (url.isEmpty() || !url.startsWith("http") || failed.contains(url)) return
        pool.execute {
            try {
                val bytes = client.newCall(Request.Builder().url(url).build()).execute().use {
                    if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
                    it.body!!.bytes()
                }
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var s = 1
                while (bounds.outWidth / s > 160) s *= 2
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
                    ?: throw IOException("çözülemedi")
                cache.put(url, bmp)
                view.post { if (view.tag == url) view.setImageBitmap(bmp) }
            } catch (e: Exception) {
                failed.add(url)
            }
        }
    }
}
