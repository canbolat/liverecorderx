package com.example.liverecorder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Alarm gelince izlenen yayını kontrol eder; canlıysa kaydı başlatır, değilse tekrar alarm kurar. */
class WatchReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("watch_id", -1)
        val pr = goAsync()
        Thread {
            try {
                val w = Watcher.get(ctx, id) ?: return@Thread
                val next = System.currentTimeMillis() + w.intervalMin * 60_000L
                if (Prefs.wifiOnly && !Prefs.onWifi(ctx)) {
                    Watcher.arm(ctx, w, next)
                    return@Thread
                }
                val live = try { StreamProbe.analyze(w.url, w.headers) != null } catch (e: Exception) { false }
                AppLog.add("I", "İzleme: ${w.url} -> ${if (live) "yayında, kayıt başlıyor" else "yayın yok"}")
                if (live) {
                    Watcher.remove(ctx, id)
                    ctx.startForegroundService(
                        Intent(ctx, RecorderService::class.java)
                            .putExtra("url", w.url).putExtra("headers", HashMap(w.headers))
                            .putExtra("bandwidth", w.bandwidth).putExtra("type", w.type)
                            .putExtra("audioOnly", w.audioOnly).putExtra("title", w.title)
                    )
                } else {
                    Watcher.arm(ctx, w, next)
                }
            } finally {
                pr.finish()
            }
        }.start()
    }
}
