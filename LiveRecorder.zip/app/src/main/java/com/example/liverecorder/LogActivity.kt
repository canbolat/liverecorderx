package com.example.liverecorder

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class LogActivity : LockedActivity() {

    private lateinit var tv: TextView
    private lateinit var sv: ScrollView

    private fun header() = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) • ${Build.MODEL}\n\n"

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeUtil.apply(this)
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.fitsSystemWindows = true

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val share = Button(this)
        share.text = "Paylaş"
        share.setOnClickListener {
            val text = header() + AppLog.read().takeLast(60_000)
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text),
                    "Günlüğü paylaş"
                )
            )
        }
        val clear = Button(this)
        clear.text = "Temizle"
        clear.setOnClickListener { AppLog.clear(); show() }
        bar.addView(share, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(clear, LinearLayout.LayoutParams(0, -2, 1f))

        sv = ScrollView(this)
        tv = TextView(this)
        tv.textSize = 12f
        tv.typeface = android.graphics.Typeface.MONOSPACE
        tv.setTextIsSelectable(true)
        val pad = (10 * resources.displayMetrics.density).toInt()
        tv.setPadding(pad, pad, pad, pad)
        sv.addView(tv)

        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        show()
    }

    private fun show() {
        val t = AppLog.read().takeLast(30_000)
        tv.text = header() + if (t.isEmpty()) "(günlük boş)" else t
        sv.post { sv.fullScroll(android.view.View.FOCUS_DOWN) }
    }
}
