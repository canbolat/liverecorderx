package com.example.liverecorder

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

/** extra "kind": "bookmarks" veya "history". */
class BookmarksActivity : LockedActivity() {

    private lateinit var kind: String
    private var items: List<LibItem> = emptyList()
    private val labels = ArrayList<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeUtil.apply(this)
        super.onCreate(savedInstanceState)
        kind = intent.getStringExtra("kind") ?: "bookmarks"
        val lv = ListView(this)
        lv.fitsSystemWindows = true
        setContentView(lv)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        lv.adapter = adapter

        lv.setOnItemClickListener { _, _, pos, _ ->
            if (pos < items.size) {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .setAction(Intent.ACTION_VIEW)
                        .setData(Uri.parse(items[pos].url))
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
                finish()
            }
        }
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos < items.size) {
                AlertDialog.Builder(this)
                    .setTitle(items[pos].title)
                    .setItems(arrayOf("Sil", "Tümünü temizle")) { _, i ->
                        if (i == 0) Library.remove(kind, pos) else Library.clear(kind)
                        load()
                    }
                    .show()
            }
            true
        }
        title = if (kind == "history") "Geçmiş" else "Yer imleri"
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        items = Library.list(kind)
        labels.clear()
        items.forEach { labels.add("${it.title}\n${it.url}") }
        if (items.isEmpty()) labels.add("Liste boş")
        adapter.notifyDataSetChanged()
    }
}
