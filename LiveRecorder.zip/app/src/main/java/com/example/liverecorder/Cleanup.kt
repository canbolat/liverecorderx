package com.example.liverecorder

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

/** Eski veya fazla yer kaplayan kayıtları siler (yalnızca uygulamanın kendi klasörlerinde). */
object Cleanup {
    private class Row(val uri: Uri, val size: Long, val added: Long)

    private fun collect(ctx: Context, out: MutableList<Row>, col: Uri, rel: String) {
        val proj = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED
        )
        ctx.contentResolver.query(
            col, proj, "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("$rel/%"), null
        )?.use { c ->
            while (c.moveToNext()) {
                out.add(Row(ContentUris.withAppendedId(col, c.getLong(0)), c.getLong(1), c.getLong(2)))
            }
        }
    }

    private fun del(ctx: Context, r: Row): Boolean = try {
        ctx.contentResolver.delete(r.uri, null, null) > 0
    } catch (e: Exception) {
        false
    }

    fun run(ctx: Context) {
        val days = Prefs.autoDeleteDays
        val maxGb = Prefs.maxTotalGb
        if (days <= 0 && maxGb <= 0) return
        try {
            val rows = ArrayList<Row>()
            collect(ctx, rows, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "Movies/LiveRecorder")
            collect(ctx, rows, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "Music/LiveRecorder")
            collect(ctx, rows, MediaStore.Downloads.EXTERNAL_CONTENT_URI, "Download/LiveRecorder")

            var deleted = 0
            val now = System.currentTimeMillis() / 1000
            val left = ArrayList<Row>()
            for (r in rows) {
                if (days > 0 && now - r.added > days * 86_400L) {
                    if (del(ctx, r)) deleted++ else left.add(r)
                } else {
                    left.add(r)
                }
            }
            if (maxGb > 0) {
                var total = left.sumOf { it.size }
                val limit = maxGb * 1_073_741_824L
                for (r in left.sortedBy { it.added }) {
                    if (total <= limit) break
                    if (del(ctx, r)) { total -= r.size; deleted++ }
                }
            }
            if (deleted > 0) AppLog.add("I", "Otomatik temizlik: $deleted dosya silindi")
        } catch (e: Exception) {
            AppLog.e("Temizlik", e)
        }
    }
}
