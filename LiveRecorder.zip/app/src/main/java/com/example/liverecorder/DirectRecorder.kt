package com.example.liverecorder

import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Doğrudan akış/dosya kaydedici: radyo (mp3, aac, ogg), canlı TS (IPTV), mp4/mkv/avi/flv/webm (VOD).
 * - Canlı ses ve TS akışı koparsa 10 dk'ya kadar yeniden bağlanır, aynı dosyaya devam eder.
 * - Boyutu bilinen büyük dosyalar (VOD) koparsa HTTP Range ile kaldığı yerden devam eder.
 * - Canlı mp3/aac/ts akışlar ayarlardaki süreye göre parçalara bölünebilir.
 */
class DirectRecorder(
    private val url: String,
    private val headers: Map<String, String>,
    private val dir: File,
    private val onStatus: (String) -> Unit
) : Recorder {

    @Volatile private var running = true
    override fun stop() { running = false }

    private val extraFiles = ArrayList<File>()
    override val extras: List<File> get() = extraFiles

    private val client = Http.client(15, 30)
    private val ua = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"
    private val audioExts = setOf("mp3", "aac", "ogg", "opus", "m4a")
    private val knownExts = audioExts + setOf("mp4", "flv", "webm", "ts", "mkv", "avi", "mov", "m4v", "wmv")
    private val liveReconnect = audioExts + "ts"
    private val splittable = setOf("mp3", "aac", "ts")

    private fun extFor(contentType: String?, u: String): String {
        val c = contentType?.substringBefore(';')?.trim()?.lowercase() ?: ""
        val path = u.substringBefore('?')
        val last = path.substringAfterLast('/')
        val fromUrl = if (last.contains('.')) last.substringAfterLast('.').lowercase() else ""
        return when {
            c == "audio/mpeg" || c == "audio/mp3" -> "mp3"
            c.startsWith("audio/aac") -> "aac"
            c == "audio/ogg" || c == "application/ogg" -> "ogg"
            c == "audio/mp4" || c == "audio/x-m4a" -> "m4a"
            c == "video/mp4" -> "mp4"
            c == "video/x-flv" -> "flv"
            c == "video/webm" -> "webm"
            c == "video/mp2t" -> "ts"
            c == "video/x-matroska" -> "mkv"
            c == "video/x-msvideo" || c == "video/avi" -> "avi"
            c == "video/quicktime" -> "mov"
            fromUrl in knownExts -> fromUrl
            path.contains("/live/") -> "ts"
            path.contains("/movie/") || path.contains("/series/") -> "mp4"
            else -> "bin"
        }
    }

    override fun run(): File {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        var out: File? = null
        var fos: FileOutputStream? = null
        var ext = ""
        var total = 0L
        var expected = -1L // Content-Length (sonlu dosyalar)
        var outageSince = 0L
        var lastNotif = 0L
        var partNo = 1
        var partStart = System.currentTimeMillis()
        val started = partStart
        var noResume = false
        val outageLimit = 10 * 60_000L
        val splitMs = Prefs.splitMin * 60_000L

        try {
            while (running) {
                val before = total
                var failed: IOException? = null
                val ranged = expected > 0 && total > 0
                try {
                    val rb = Request.Builder().url(url)
                        .header("User-Agent", ua)
                        .header("Icy-MetaData", "0") // ses içine metadata karıştırma
                    headers.forEach { (k, v) -> rb.header(k, v) }
                    if (ranged) rb.header("Range", "bytes=$total-")
                    client.newCall(rb.build()).execute().use { resp ->
                        if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                        if (ranged && resp.code != 206) { // sunucu devam etmeyi desteklemiyor
                            noResume = true
                            return@use
                        }
                        if (out == null) {
                            ext = extFor(resp.header("Content-Type"), url)
                            val f = File(dir, "kayit_$stamp.$ext")
                            out = f
                            fos = FileOutputStream(f)
                            partStart = System.currentTimeMillis()
                        }
                        val body = resp.body!!
                        if (!ranged) {
                            val cl = body.contentLength()
                            if (cl > 0) expected = cl
                        }
                        val src = body.byteStream()
                        val buf = ByteArray(64 * 1024)
                        while (running) {
                            val n = src.read(buf)
                            if (n < 0) break
                            val now = System.currentTimeMillis()
                            if (splitMs > 0 && expected < 0 && ext in splittable && now - partStart >= splitMs) {
                                fos!!.close()
                                partNo++
                                val pf = File(dir, "kayit_${stamp}_p$partNo.$ext")
                                extraFiles.add(pf)
                                fos = FileOutputStream(pf)
                                partStart = now
                            }
                            fos!!.write(buf, 0, n)
                            total += n
                            if (now - lastNotif > 2000) {
                                lastNotif = now
                                onStatus(
                                    if (expected > 0) "İndiriliyor: %${total * 100 / expected} • ${total / 1_000_000} MB"
                                    else "Kaydediliyor: ${total / 1_000_000} MB • ${(now - started) / 60_000} dk"
                                )
                            }
                        }
                    }
                } catch (e: IOException) {
                    failed = e
                }

                if (!running) break
                if (out == null && failed != null) throw failed // hiç bağlanılamadı
                if (noResume) break
                if (expected > 0 && total >= expected) break    // dosya tamamen indi

                val now = System.currentTimeMillis()
                if (total > before) {
                    outageSince = 0L
                } else {
                    if (outageSince == 0L) outageSince = now
                    if (now - outageSince > outageLimit) break
                }

                val reconnect = expected > 0 || ext in liveReconnect
                if (!reconnect) break // bilinmeyen boyutlu video: parçaları birleştirmek bozar
                onStatus(if (expected > 0) "Bağlantı koptu, kaldığı yerden devam ediliyor…" else "Bağlantı koptu, yeniden bağlanılıyor…")
                try { Thread.sleep(2000) } catch (_: InterruptedException) { break }
            }
        } finally {
            try { fos?.close() } catch (_: IOException) {}
        }

        val f = out
        if (f == null || total == 0L) {
            f?.delete()
            throw IOException("Kayıt boş (veri gelmedi)")
        }
        return f
    }
}
