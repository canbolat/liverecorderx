package com.example.liverecorder

import android.net.Uri

/** Sosyal medya bağlantılarını tanır (video indirme için). */
object Social {
    private val hosts = listOf(
        "instagram.com", "facebook.com", "fb.watch", "fb.com", "tiktok.com", "twitter.com", "x.com",
        "threads.net", "reddit.com", "redd.it", "vimeo.com", "dailymotion.com", "pinterest.com",
        "pin.it", "snapchat.com", "linkedin.com", "tumblr.com", "twitch.tv", "bsky.app"
    )

    fun isSocial(url: String): Boolean {
        val h = Uri.parse(url).host?.lowercase() ?: return false
        return hosts.any { h == it || h.endsWith(".$it") }
    }
}
