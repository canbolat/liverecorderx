package com.example.liverecorder

import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

/**
 * Oynatıcı (ExoPlayer): kayıtlar, önizleme ve IPTV için. HLS/DASH/TS/FLV/MP4 oynatır;
 * hata ve takılmada otomatik yeniden bağlanır; geniş arabellek ile donmayı azaltır.
 */
class PlayerActivity : LockedActivity() {

    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private lateinit var bar: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var statusTv: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var retry = 0
    private var iptv = false

    private var curUri: Uri? = null
    private var curHeaders: Map<String, String> = emptyMap()
    private var curTitle = ""
    private var curMime: String? = null

    private val stallRun = Runnable { recover("Takıldı, yeniden bağlanılıyor…") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        iptv = intent.getBooleanExtra("iptv", false)

        val dp = resources.displayMetrics.density
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        view = PlayerView(this)
        view.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
        root.addView(view, FrameLayout.LayoutParams(-1, -1))

        bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Color.argb(150, 0, 0, 0))
        bar.setPadding((10 * dp).toInt(), (6 * dp).toInt(), (10 * dp).toInt(), (6 * dp).toInt())
        titleTv = TextView(this)
        titleTv.setTextColor(Color.WHITE)
        titleTv.textSize = 16f
        titleTv.maxLines = 1
        bar.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f))
        if (iptv) {
            fun btn(t: String, onClick: () -> Unit) {
                val b = Button(this)
                b.text = t
                b.setOnClickListener { onClick() }
                bar.addView(b, LinearLayout.LayoutParams(-2, -2))
            }
            btn("◀") { zap(-1) }
            btn("▶") { zap(1) }
            btn("⏺ Kaydet") { recordCurrent() }
        }
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        statusTv = TextView(this)
        statusTv.setTextColor(Color.WHITE)
        statusTv.setBackgroundColor(Color.argb(160, 0, 0, 0))
        statusTv.setPadding((14 * dp).toInt(), (8 * dp).toInt(), (14 * dp).toInt(), (8 * dp).toInt())
        statusTv.visibility = View.GONE
        root.addView(statusTv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        setContentView(root)
        view.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v -> bar.visibility = v })
        resolveSource()
    }

    override fun onStart() {
        super.onStart()
        if (player == null) buildPlayer()
    }

    override fun onStop() {
        releasePlayer()
        super.onStop()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus) return
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }

    // ---- Kaynak ----
    private fun resolveSource() {
        val q = IptvStore.queue
        if (iptv && q.isNotEmpty()) {
            val ch = q[IptvStore.queueIndex.coerceIn(0, q.size - 1)]
            curUri = Uri.parse(ch.url)
            curHeaders = ch.headers
            curTitle = ch.name
            curMime = if (Iptv.typeOf(ch.url) == "hls") MimeTypes.APPLICATION_M3U8 else null
        } else {
            curUri = intent.data
            @Suppress("DEPRECATION", "UNCHECKED_CAST")
            val hdr = intent.getSerializableExtra("headers") as? HashMap<String, String>
            curHeaders = hdr ?: emptyMap()
            curTitle = intent.getStringExtra("title") ?: ""
            val p = curUri?.toString()?.substringBefore('?')?.lowercase() ?: ""
            curMime = if (p.startsWith("http") && p.endsWith(".m3u8")) MimeTypes.APPLICATION_M3U8 else null
        }
        titleTv.text = curTitle
    }

    // ---- Oynatıcı ----
    private fun buildPlayer() {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(curHeaders["User-Agent"] ?: "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .setDefaultRequestProperties(curHeaders.filterKeys { !it.equals("User-Agent", true) })
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
            .setAllowCrossProtocolRedirects(true)
        val p = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(20_000, 60_000, 2_500, 5_000).build())
            .build()
        p.addListener(listener)
        view.setPlayer(p)
        player = p
        val item = MediaItem.Builder().setUri(curUri)
        curMime?.let { item.setMimeType(it) }
        p.setMediaItem(item.build())
        p.prepare()
        p.playWhenReady = true
    }

    private fun releasePlayer() {
        handler.removeCallbacks(stallRun)
        val p = player ?: return
        view.setPlayer(null)
        p.release()
        player = null
    }

    private val listener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            val p = player ?: return
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                p.seekToDefaultPosition()
                p.prepare()
                return
            }
            AppLog.add("W", "Oynatıcı hatası ${error.errorCode}: ${error.message}")
            recover("Bağlantı hatası")
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            handler.removeCallbacks(stallRun)
            when (playbackState) {
                Player.STATE_READY -> { retry = 0; statusTv.visibility = View.GONE }
                Player.STATE_BUFFERING -> handler.postDelayed(stallRun, 25_000)
            }
        }
    }

    private fun recover(msg: String) {
        if (player == null) return
        retry++
        statusTv.visibility = View.VISIBLE
        if (retry > 10) {
            statusTv.text = "Oynatılamadı. Yayın kapalı olabilir ya da erişim engelli."
            return
        }
        statusTv.text = "$msg ($retry/10)"
        handler.postDelayed({
            val pl = player ?: return@postDelayed
            if (pl.isCurrentMediaItemLive) pl.seekToDefaultPosition() else pl.seekTo(pl.currentPosition)
            pl.prepare()
        }, minOf(1500L * retry, 8000L))
    }

    // ---- IPTV: kanal değiştir / kaydet ----
    private fun zap(d: Int) {
        val q = IptvStore.queue
        if (q.isEmpty()) return
        IptvStore.queueIndex = (IptvStore.queueIndex + d + q.size) % q.size
        retry = 0
        statusTv.visibility = View.GONE
        releasePlayer()
        resolveSource()
        buildPlayer()
    }

    private fun recordCurrent() {
        val q = IptvStore.queue
        if (q.isEmpty()) return
        val ch = q[IptvStore.queueIndex.coerceIn(0, q.size - 1)]
        Toast.makeText(this, "Yayın kontrol ediliyor…", Toast.LENGTH_SHORT).show()
        Thread {
            val t = Iptv.detectType(ch.url, ch.headers)
            runOnUiThread {
                startForegroundService(Iptv.recordIntent(this, ch, t, 0))
                Toast.makeText(this, "Kayıt başladı: ${ch.name}", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }
}
