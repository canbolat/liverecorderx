package com.example.liverecorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import android.os.StatFs
import android.service.quicksettings.TileService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class RecorderService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.liverecorder.STOP"
        const val EXTRA_ID = "id"
        private const val CHANNEL = "rec"
        private const val FG_ID = 1
        /** Hızlı ayar kutucuğu için çalışan kayıt sayısı. */
        @Volatile var activeCount = 0
    }

    private class Done(val msg: String, val uri: Uri?)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val recorders = ConcurrentHashMap<Int, Recorder>()
    private val pending = java.util.ArrayDeque<Intent>()
    private val nextId = AtomicInteger(100)
    private lateinit var nm: NotificationManager
    @Volatile private var stopReason: String? = null
    private var watchdog: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val subExts = setOf("vtt", "srt", "ttml", "json")

    private val dir: File get() = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Kayıt", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            val id = intent.getIntExtra(EXTRA_ID, -1)
            if (id >= 0) {
                recorders[id]?.stop()
            } else {
                synchronized(pending) { pending.clear() }
                recorders.values.forEach { it.stop() }
            }
            if (recorders.isEmpty()) stopSelf()
            return START_NOT_STICKY
        }
        if (intent == null || intent.getStringExtra("url") == null) {
            if (recorders.isEmpty()) stopSelf()
            return START_NOT_STICKY
        }

        startForeground(FG_ID, summary(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        if (Prefs.wifiOnly && !Prefs.onWifi(this)) {
            AppLog.add("W", "Kayıt reddedildi: yalnızca Wi-Fi ayarı açık")
            nm.notify(nextId.incrementAndGet(), simple("Yalnızca Wi-Fi ayarı açık, kayıt başlatılmadı"))
            maybeStop()
            return START_NOT_STICKY
        }
        if (freeLow()) {
            AppLog.add("W", "Kayıt reddedildi: boş alan yetersiz")
            nm.notify(nextId.incrementAndGet(), simple("Boş alan yetersiz, kayıt başlatılmadı"))
            maybeStop()
            return START_NOT_STICKY
        }
        if (recorders.size >= Prefs.maxConcurrent) {
            synchronized(pending) { pending.add(Intent(intent)) }
            nm.notify(FG_ID, summary())
            return START_NOT_STICKY
        }
        begin(intent)
        return START_NOT_STICKY
    }

    // ---- Uyku kilidi ----
    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        if (wakeLock == null) {
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LiveRecorder:rec").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
        if (wifiLock == null) {
            val wm = applicationContext.getSystemService(WifiManager::class.java)
            wifiLock = wm?.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "LiveRecorder:wifi")?.apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun releaseLocks() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        try { wifiLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
        wifiLock = null
    }

    private fun updateTile() {
        activeCount = recorders.size
        try {
            TileService.requestListeningState(this, ComponentName(this, StopTileService::class.java))
        } catch (_: Exception) {
        }
    }

    // ---- Koruma: depolama ve Wi-Fi ----
    private fun freeLow(): Boolean = try {
        StatFs(dir.path).availableBytes < Prefs.minFreeMb * 1_048_576L
    } catch (e: Exception) {
        false
    }

    private fun ensureWatchdog() {
        if (watchdog != null) return
        watchdog = scope.launch {
            while (recorders.isNotEmpty()) {
                delay(15_000)
                guard()
            }
            watchdog = null
        }
    }

    private fun guard() {
        var why: String? = null
        if (freeLow()) why = "Boş alan azaldı"
        if (why == null && Prefs.wifiOnly && !Prefs.onWifi(this)) why = "Wi-Fi bağlantısı kesildi"
        if (why != null) {
            AppLog.add("W", "Kayıtlar durduruluyor: $why")
            stopReason = why
            synchronized(pending) { pending.clear() }
            recorders.values.forEach { it.stop() }
        }
    }

    private fun maybeStop() {
        val none = synchronized(pending) { pending.isEmpty() }
        if (recorders.isEmpty() && none) {
            releaseLocks()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun startNextPending() {
        while (recorders.size < Prefs.maxConcurrent) {
            val i = synchronized(pending) { pending.poll() } ?: break
            begin(i)
        }
    }

    // ---- Kaydı başlat ----
    private fun begin(intent: Intent) {
        val url = intent.getStringExtra("url") ?: return
        @Suppress("DEPRECATION", "UNCHECKED_CAST")
        val headers = (intent.getSerializableExtra("headers") as? HashMap<String, String>) ?: HashMap()
        val bandwidth = intent.getLongExtra("bandwidth", 0L)
        val durationMin = intent.getIntExtra("duration", 0)
        val audioOnly = intent.getBooleanExtra("audioOnly", false)
        val title = intent.getStringExtra("title") ?: ""
        val cookies = intent.getStringExtra("cookies")
        val typeExtra = intent.getStringExtra("type") ?: ""
        val isMpd = url.substringBefore('?').lowercase().endsWith(".mpd")
        val type = if (typeExtra.isNotEmpty()) typeExtra else if (isMpd) "dash" else "hls"

        if (recorders.isEmpty()) stopReason = null
        val id = nextId.incrementAndGet()
        val status: (String) -> Unit = { nm.notify(id, notif(id, it)) }
        val rec: Recorder = when (type) {
            "dash" -> DashRecorder(url, headers, dir, bandwidth, audioOnly, status)
            "direct" -> DirectRecorder(url, headers, dir, status)
            "social" -> SocialRecorder(applicationContext, url, dir, audioOnly, intent.getIntExtra("height", 0), cookies, status)
            else -> HlsRecorder(url, headers, dir, bandwidth, audioOnly, status)
        }
        recorders[id] = rec
        AppLog.add("I", "Kayıt #${id - 100} başladı ($type${if (audioOnly) ", ses" else ""}): $url")
        acquireLocks()
        updateTile()
        nm.notify(id, notif(id, "Hazırlanıyor…"))
        nm.notify(FG_ID, summary())
        ensureWatchdog()

        val timer = if (durationMin > 0) scope.launch {
            delay(durationMin * 60_000L)
            rec.stop()
        } else null

        scope.launch {
            val done = try {
                saveAll(rec, id, audioOnly, type, title)
            } catch (e: Exception) {
                AppLog.e("Kayıt #${id - 100}", e)
                Done("Hata: ${e.message}", null)
            }
            timer?.cancel()
            recorders.remove(id)
            updateTile()
            val reason = stopReason
            val text = if (reason != null) "${done.msg} ($reason)" else done.msg
            AppLog.add("I", "Kayıt #${id - 100} bitti: $text")
            nm.notify(id, notif(id, text, ongoing = false, openUri = done.uri))
            try { Cleanup.run(this@RecorderService) } catch (_: Exception) {}
            startNextPending()
            maybeStop()
            if (recorders.isNotEmpty()) nm.notify(FG_ID, summary())
        }
    }

    /** Dosya adını sayfa başlığıyla değiştirir (kayit_ öneki yerine). */
    private fun withTitle(f: File, title: String): File {
        if (title.isEmpty() || !f.name.startsWith("kayit_")) return f
        val safe = title.replace(Regex("[^\\p{L}\\p{N} _.-]"), "").trim()
            .replace(Regex("\\s+"), "_").take(60)
        if (safe.isEmpty()) return f
        val nf = File(f.parentFile, safe + "_" + f.name.removePrefix("kayit_"))
        return if (!nf.exists() && f.renameTo(nf)) nf else f
    }

    /** Kaydı bitirir, gerekirse dönüştürür ve tüm dosyaları (parça, altyazı) galeriye taşır. */
    private fun saveAll(rec: Recorder, id: Int, audioOnly: Boolean, type: String, title: String): Done {
        val main = rec.run()
        val all = (listOf(main) + rec.extras).map { withTitle(it, title) }
        val saved = ArrayList<String>()
        var firstUri: Uri? = null
        all.forEachIndexed { idx, f ->
            val fin = if (f.extension.lowercase() in subExts) f else finishFile(f, id, audioOnly, type)
            try {
                val s = MediaSaver.saveWithUri(this, fin)
                saved.add(s.path)
                if (idx == 0) firstUri = s.uri
            } catch (e: Exception) {
                AppLog.e("Galeriye taşıma", e)
                saved.add(fin.absolutePath + " (galeriye taşınamadı)")
            }
        }
        val msg = if (saved.size == 1) "Kaydedildi: ${saved[0]}"
        else "Kaydedildi (${saved.size} dosya): ${saved[0]} …"
        return Done(msg, firstUri)
    }

    /** Sadece ses isteniyorsa M4A'ya, HLS .ts ise MP4'e çevir. Başarısız olursa dosya olduğu gibi kalır. */
    private fun finishFile(f: File, id: Int, audioOnly: Boolean, type: String): File {
        val ext = f.extension.lowercase()
        if (type == "social" || (type == "direct" && ext != "ts")) return f
        val target = when {
            audioOnly && ext != "m4a" -> "m4a"
            !audioOnly && ext == "ts" -> "mp4"
            else -> return f
        }
        nm.notify(id, notif(id, if (target == "m4a") "Sese çevriliyor…" else "MP4'e çevriliyor…"))
        val dst = File(f.parentFile, f.nameWithoutExtension + "." + target)
        return try {
            Remuxer.toMp4(f, dst, audioOnly)
            f.delete()
            dst
        } catch (e: Exception) {
            AppLog.e("Dönüştürme", e)
            dst.delete()
            f
        }
    }

    /** Android 15: dataSync ön plan servislerinin süre sınırı doldu. Kayıtları durdurup servisi kapat. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        AppLog.add("W", "Android servis süre sınırı doldu, kayıtlar durduruluyor")
        stopReason = "Android servis süre sınırı"
        synchronized(pending) { pending.clear() }
        recorders.values.forEach { it.stop() }
        releaseLocks()
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    // ---- Bildirimler ----
    private fun stopIntent(id: Int): PendingIntent {
        val i = Intent(this, RecorderService::class.java).setAction(ACTION_STOP)
        if (id >= 0) i.putExtra(EXTRA_ID, id)
        return PendingIntent.getService(this, if (id >= 0) id else 0, i, PendingIntent.FLAG_IMMUTABLE)
    }

    @Suppress("DEPRECATION")
    private fun summary(): Notification {
        val q = synchronized(pending) { pending.size }
        val text = "${recorders.size} kayıt sürüyor" + if (q > 0) " • $q sırada" else ""
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Live Recorder")
            .setContentText(text)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Tümünü durdur", stopIntent(-1))
            .build()
    }

    private fun simple(text: String): Notification =
        Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Live Recorder")
            .setContentText(text)
            .build()

    @Suppress("DEPRECATION")
    private fun notif(id: Int, text: String, ongoing: Boolean = true, openUri: Uri? = null): Notification {
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Kayıt #${id - 100}")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOngoing(ongoing)
        if (ongoing) b.addAction(android.R.drawable.ic_media_pause, "Durdur", stopIntent(id))
        if (!ongoing && openUri != null) {
            // Dokununca oynat, "Paylaş" ile gönder
            val open = Intent(this, PlayerActivity::class.java).setData(openUri)
            b.setContentIntent(PendingIntent.getActivity(this, id, open, PendingIntent.FLAG_IMMUTABLE))
            b.setAutoCancel(true)
            val send = Intent(Intent.ACTION_SEND)
                .setType(contentResolver.getType(openUri) ?: "video/*")
                .putExtra(Intent.EXTRA_STREAM, openUri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            b.addAction(
                android.R.drawable.ic_menu_share, "Paylaş",
                PendingIntent.getActivity(this, id + 10_000, Intent.createChooser(send, "Paylaş"), PendingIntent.FLAG_IMMUTABLE)
            )
        }
        return b.build()
    }

    override fun onDestroy() {
        releaseLocks()
        updateTile()
        scope.cancel()
        super.onDestroy()
    }
}
