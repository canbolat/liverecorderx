# Live Recorder (Kotlin)

Tincat tarzı: WebView tarayıcı + m3u8/mpd algılama + kayıt.

## Çalıştırma
1. Android Studio (Koala+ / JDK 17) ile `LiveRecorder` klasörünü aç, Gradle sync yap.
2. Telefonda çalıştır, bir yayın sayfası aç, yayını oynat.
3. Listedeki linke dokun -> kalite seç -> "Şimdi kaydet" veya "Zamanla".
4. Kayıtlar Galeri'de: Movies/LiveRecorder/ ("Kayıtlar" düğmesi ile uygulamadan da açılır; uzun bas = sil).

## Özellikler
- HLS (.m3u8) ve DASH (.mpd, SegmentTemplate) kaydı; canlı + VOD; fMP4 ve MediaMuxer ile video+ses birleştirme.
- Kalite seçimi, aynı anda birden fazla kayıt, zamanlı kayıt (tam zamanlı alarm), uygulama içi oynatıcı.
- Cookie/Referer/Origin/User-Agent başlıkları WebView'den alınır.
- Android 15 dataSync servis süre sınırı (onTimeout) ele alınır.
- Yayın listesi: reklam/izleme linkleri filtrelenir, her link analiz edilir (CANLI/süre/çözünürlük), en olası ana yayın ★ ile en üstte.
- Zamanlı kayıtlar kalıcıdır (telefon yeniden başlayınca geri yüklenir); "Zamanlı" düğmesinden listelenir/iptal edilir.
- HLS .ts kayıtlar bitince otomatik MP4'e çevrilir; eski .ts kayıtlar için Kayıtlar > uzun bas > MP4'e çevir.
- Kayıtlar: uzun bas = Paylaş / Yeniden adlandır / MP4'e çevir / Sil.

- AES-128 şifreli HLS çözülür; internet koparsa 10 dk'ya kadar yeniden dener, yayın bitince kendiliğinden kaydı kapatır.
- Link ekleme: adres çubuğuna m3u8/mpd linki yapıştır, ya da başka uygulamadan "Paylaş" / "Şununla aç" ile gönder (sayfa linki paylaşılırsa tarayıcıda açılıp yayın aranır).

- Doğrudan akışlar: Icecast/Shoutcast radyo (mp3/aac/ogg), mp4, flv, webm kaydedilir. Uzantısız linkler içerik türüne bakılarak (m3u8/mpd/ses/video) doğrulanır.
- "Sadece ses kaydet": HLS/DASH yayından yalnızca sesi M4A olarak kaydeder (Müzik/LiveRecorder). Radyo kayıtları da Müzik'e gider.
- "Git" düğmesine uzun bas: adres çubuğundaki linki (uzantısız olsa da, ör. radyo linki) yayın olarak ekler.

- Paralel indirme: bitmiş (VOD) HLS'te 6 parça aynı anda iner, sırayla yazılır.
- Ayrı ses akışı olan HLS'te video+ses birlikte kaydedilip MP4'te birleştirilir; ses dili seçilebilir (Ayarlar). DASH'te de ses dili tercihi uygulanır.
- Altyazı: HLS (WebVTT) ve tek dosyalık DASH altyazıları yan dosya olarak Download/LiveRecorder'a kaydedilir (zamanlama kayabilir).
- "Yayın başlayınca kaydet": linki 2/5/15 dk'da bir kontrol eder, yayın açılınca kaydı başlatır (tek seferlik). "Zamanlı" ekranından iptal edilir.
- Koruma: yalnızca Wi-Fi, boş alan sınırı, kaydı otomatik bölme (tek parçalı HLS ve mp3/aac akışlar), eşzamanlı kayıt sınırı + sıra.
- Tarayıcı: yer imi, geçmiş, reklam engelleme (alan adı listesi, ayarlardan düzenlenir), karanlık mod.
- Ağ: HTTP/SOCKS proxy ve şifreli DNS (Cloudflare/Google) kayıt ve analiz isteklerinde uygulanır.

- Günlük ekranı (⋮ > Günlük): hatalar ve olaylar kaydedilir; "Paylaş" ile gönderilebilir. Çökmeler de yazılır.
- Uzun kayıtlar için uyku kilidi + Wi-Fi kilidi; Ayarlar'dan pil optimizasyonu muafiyeti istenir.
- Kayıt bitince bildirime dokunarak oynat, "Paylaş" ile gönder. Dosya adı sayfa başlığından üretilir.
- Panodaki m3u8/mpd linki algılanır (Ayarlar'dan kapatılabilir). "Önizle" ile kaydetmeden izlenir (HLS/direkt).
- Kayıtlar > uzun bas: Kırp (yeniden kodlamasız), Sıkıştır (Media3 Transformer ile 720/480/360p).
- HLS reklam işaretleri (CUE-OUT/CUE-IN, SCTE-35, stitched-ad) olan parçalar atlanır (en fazla 10 dk üst üste).
- Otomatik temizlik (gün / toplam boyut), ayar-yer imi-izleme yedekleme (JSON), hızlı ayar kutucuğu ("Kayıtları durdur").

- Sosyal medya video indirme (Instagram, Facebook, TikTok, X, Reddit, Vimeo vb.): ⋮ menüsü > "Bu sayfadaki videoyu indir", ya da link paylaş/panoya kopyala. yt-dlp motoru (youtubedl-android) kullanılır; Ayarlar'dan güncellenebilir. Tarayıcıda giriş yaptıysan oturum çerezleri geçici dosyayla yt-dlp'ye verilir ve indirme bitince silinir.

- Hızlı paylaş: başka uygulamadan sosyal medya linki paylaşınca soru sormadan varsayılan kaliteyle indirir (Ayarlar'dan kapatılır). Normal indirmede kalite seçilir (en iyi / 1080p / 720p / 480p / sadece ses).
- Uygulama kilidi (Ayarlar > Güvenlik): PIN veya PIN + parmak izi; açıkken ekran görüntüsü ve son uygulamalar önizlemesi engellenir; arka plandan 30 sn içinde dönülürse tekrar sormaz. 5 yanlış denemede 30 sn bekletir. Rahatlık amaçlı bir kilittir, cihazın kendisinin kilidi kadar güçlü değildir.

- IPTV (⋮ > IPTV): M3U playlist ekle (link / dosya / dosya yöneticisinden aç), sil, yenile, yeniden adlandır. Canlı TV / VOD / Favoriler sekmeleri, kategori (group-title) filtresi, arama, kanal logoları. Kanala uzun bas: kaydet, zamanla, yayın başlayınca kaydet, EPG'den program kaydet, VOD'u indir (kopmada kaldığı yerden devam). Oynatıcı ExoPlayer: geniş arabellek, hata/takılmada otomatik yeniden bağlanma, kanal değiştirme ve oynatırken kaydetme.
- EPG (XMLTV, .gz desteklenir): listedeki url-tvg adresinden otomatik, istersen elle adres. Kanalda "şimdi oynayan", program listesi ve programı otomatik kaydetme.

## Sınırlar
- DRM (Widevine vb.), SAMPLE-AES, SegmentBase/SegmentList, çoklu Period desteklenmez.
- Tokenlı linkler zamanla geçersiz olabilir (zamanlı kayıt başlayınca hata verebilir).
- Reklam atlama yalnızca işaretli akışlarda çalışır; işaretsiz (sunucu tarafı enjekte) reklamlar atlanamaz.
- Sıkıştırma yeniden kodlama yaptığı için yavaştır; ekran açık tutulmalı.
- Sosyal medya indirici yalnızca arm64-v8a (çoğu modern telefon) için paketlenir; APK yaklaşık 80-120 MB olur. Instagram/Facebook çoğu gönderi için giriş ister; siteler değişince indirme bozulabilir (Ayarlar'dan motoru güncelle). Fotoğraf gönderileri indirilmez.
- IPTV'de yalnızca http/https adresler desteklenir (rtmp, udp, rtsp atlanır). Uygulama hiçbir hazır liste içermez; yalnızca erişim hakkın olan listeleri ekle.
- Bölme ayrı ses/video akışlarında (DASH, demuxed HLS) uygulanmaz.
- Proxy/DNS tarayıcı gezinmesini kapsamaz.
- Dahili oynatıcı bazı .ts dosyalarını açamazsa harici oynatıcıya yönlendirir.
